// hide-element.js
console.log("🔥 Ilimitado Lov: Sniper iniciado...");

const TEXTO_ALVO = "Fix all security issues";

// Seletores da badge "Powered by Lovable" — esconde via CSS no preview
function esconderBadgeLovable() {
    const BADGE_SELECTORS = [
        // Badge flutuante padrão do Lovable
        'a[href*="lovable.dev"][target="_blank"]',
        '[class*="lovable-badge"]',
        '[id*="lovable-badge"]',
        // Texto "Powered by Lovable" / "Built with Lovable"
        'a[href*="lovable.app"]',
        'a[href*="gpteng.co"]',
        // Selo no canto da tela
        'div[style*="position: fixed"][style*="bottom"]',
    ];

    BADGE_SELECTORS.forEach(sel => {
        try {
            document.querySelectorAll(sel).forEach(el => {
                // Verificar se contém texto relacionado ao Lovable
                const txt = el.textContent.toLowerCase();
                if (txt.includes('lovable') || txt.includes('gpt engineer') || txt.includes('built with')) {
                    el.style.setProperty('display', 'none', 'important');
                    el.style.setProperty('visibility', 'hidden', 'important');
                    el.style.setProperty('opacity', '0', 'important');
                    el.style.setProperty('pointer-events', 'none', 'important');
                }
            });
        } catch(e) {}
    });

    // Injetar CSS global para garantir
    if (!document.getElementById('ilimitado-hide-badge')) {
        const style = document.createElement('style');
        style.id = 'ilimitado-hide-badge';
        style.textContent = `
            a[href*="lovable.dev"][target="_blank"],
            a[href*="lovable.app"],
            [class*="lovable-badge"],
            [id*="lovable-badge"],
            [data-testid*="badge"] {
                display: none !important;
                visibility: hidden !important;
                opacity: 0 !important;
            }
        `;
        document.head?.appendChild(style);
    }
}

esconderBadgeLovable();
setInterval(esconderBadgeLovable, 500);
new MutationObserver(esconderBadgeLovable).observe(document.documentElement, { childList: true, subtree: true });

function destruirElemento() {
    // Procura elementos que contenham o texto exato
    const xpath = `//*[contains(text(), '${TEXTO_ALVO}')]`;
    
    try {
        const snapshot = document.evaluate(
            xpath, 
            document, 
            null, 
            XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, 
            null
        );

        for (let i = 0; i < snapshot.snapshotLength; i++) {
            let element = snapshot.snapshotItem(i);
            
            if (element && element.textContent.includes(TEXTO_ALVO)) {
                // Tenta achar o container pai que tem a classe 'overflow-wrap-anywhere'
                // ou sobe 4 níveis para garantir que pegamos a caixa toda
                let alvo = element.closest('.overflow-wrap-anywhere') || 
                           element.closest('.special-message') || 
                           element.parentElement.parentElement ||
                           element;

                if (alvo && alvo.style.display !== 'none') {
                    console.log("🎯 ALVO DETECTADO E REMOVIDO:", alvo);
                    
                    // Aplica remoção agressiva
                    alvo.style.display = 'none';
                    alvo.style.visibility = 'hidden';
                    alvo.innerHTML = ''; // Esvazia o conteúdo
                    alvo.remove(); // Remove do DOM
                }
            }
        }
    } catch (e) {
        // Silêncio é ouro
    }
}

// 1. Executa imediatamente
destruirElemento();

// 2. Executa repetidamente (ideal para Single Page Apps como o Lovable)
setInterval(destruirElemento, 200);

// 3. Monitora mudanças na página
const observer = new MutationObserver(() => destruirElemento());
observer.observe(document.body, { childList: true, subtree: true });

// ========== PUBLISH PROJECT HANDLER ==========
// Thin Client: encaminha para o background que chama o backend
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'publishProject') {
        console.log('🚀 Publicando projeto via backend:', request.projectId);
        chrome.runtime.sendMessage({
            action: 'ilimitadoAction',
            kind: 'approve',
            projectId: request.projectId
        }, (resp) => {
            if (chrome.runtime.lastError) {
                sendResponse({ success: false, error: chrome.runtime.lastError.message });
                return;
            }
            sendResponse(resp || { success: false, error: 'Sem resposta' });
        });
        return true;
    }
});