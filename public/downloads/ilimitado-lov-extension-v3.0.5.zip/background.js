// ============================================================
// Ilimitado Lov - Background Service Worker v4.0.0
// ============================================================
// THIN CLIENT: A extensão apenas intercepta e captura dados.
// Toda lógica de envio é delegada ao backend (process-message).
//
// Responsabilidades:
//   1. Auto-captura do token e projectId via webRequest
//   2. Injeção do ApproveGuard (intercepta Send + Enter + Approve)
//   3. Proxy de envio via Edge Function process-message
//   4. Helpers simples (openUrl)
// ============================================================

const SUPABASE_URL = 'https://rmetppilvfrxosvxzhgj.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJtZXRwcGlsdmZyeG9zdnh6aGdqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzAwNjE2MzgsImV4cCI6MjA4NTYzNzYzOH0.9ClXH2tomnJAGf0BSTAsJ7v4DTfnKQ8DDcrFj8mbqxY';

const APPROVE_GUARD_STORAGE_KEY = 'approveGuardTabs';
let approveGuardTabs = {};

chrome.storage.local.get([APPROVE_GUARD_STORAGE_KEY], (result) => {
  const s = result?.[APPROVE_GUARD_STORAGE_KEY];
  approveGuardTabs = s && typeof s === 'object' ? s : {};
});

function persistApproveGuardState() { chrome.storage.local.set({ [APPROVE_GUARD_STORAGE_KEY]: approveGuardTabs }); }
function setApproveGuardState(tabId, isActive) {
  const key = String(tabId || '');
  if (!key) return;
  if (isActive) approveGuardTabs[key] = true;
  else delete approveGuardTabs[key];
  persistApproveGuardState();
}
function hasApproveGuardState(tabId) { return !!approveGuardTabs[String(tabId || '')]; }
function isLovableUrl(url) { return /^https:\/\/([a-z0-9-]+\.)*lovable\.dev(\/|$)/i.test(String(url || '')); }

// ── 1. Auto-captura de token e projectId via webRequest ───────────────────────
chrome.webRequest.onBeforeSendHeaders.addListener(
  (details) => {
    const headers = details.requestHeaders || [];
    for (const h of headers) {
      const name = String(h?.name || '').toLowerCase();
      if (name === 'authorization') {
        const token = String(h.value || '').replace(/^Bearer\s+/i, '').trim();
        if (token.length > 20) {
          chrome.storage.local.set({ authToken: token, lovable_token: token });
        }
      }
    }
    const urlMatch = String(details.url || '').match(/projects\/([a-f0-9-]+)/i);
    if (urlMatch?.[1]) {
      chrome.storage.local.set({ projectId: urlMatch[1] });
    }
  },
  { urls: ['https://api.lovable.dev/*'] },
  ['requestHeaders']
);

// ── 2. ApproveGuard — intercepta o chat nativo da Lovable ────────────────────
// Quando o usuário clica Send/Enter/Approve, captura o texto e arquivos
// e envia ao backend via sendMessage → background → process-message
async function executeScriptSafe(tabId, func) {
  try {
    await chrome.scripting.executeScript({ target: { tabId }, world: 'ISOLATED', func });
    return true;
  } catch (_) { return false; }
}

async function activateApproveGuard(tabId) {
  return executeScriptSafe(tabId, () => {
    const RUNTIME_KEY = '__ilimitadoApproveGuardController';
    const TOAST_ID    = '__ilimitadoApproveGuardToast';
    const TOKEN_ATTR  = 'data-ilimitado-guard-token';
    const controllerToken = `lov_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

    const tokenRoot = document.documentElement || document.body;
    if (tokenRoot) tokenRoot.setAttribute(TOKEN_ATTR, controllerToken);

    const existing = window[RUNTIME_KEY];
    if (existing && existing.cleanup) existing.cleanup();

    const normalize = (v) => String(v || '').replace(/\s+/g, ' ').trim().toLowerCase();
    const getText = (el) => String(
      el && (el.getAttribute && (el.getAttribute('aria-label') || el.getAttribute('title'))) || (el && el.textContent) || ''
    ).replace(/\s+/g, ' ').trim();

    const getEventTarget = (e) => {
      const t = e && e.target;
      if (t && typeof t.closest === 'function') return t;
      const path = e && typeof e.composedPath === 'function' ? e.composedPath() : [];
      const p = Array.isArray(path) ? path[0] : null;
      return (p && typeof p.closest === 'function') ? p : (p && p.parentElement) || (t && t.parentElement) || null;
    };

    const isInsideChatInput = (el) => !!(el && el.closest &&
      el.closest('[contenteditable="true"][aria-label="Chat input"], [contenteditable="true"], #chatinput, form#chat-input, form[id*="chat-input"]')
    );

    const isNativeSendBtn = (el) => {
      if (!el) return false;
      if (el.id === 'chatinput-send-message-button') return true;
      if (el.closest && el.closest('#chatinput-send-message-button')) return true;
      const aria = normalize(el.getAttribute && el.getAttribute('aria-label') || '');
      return (aria.includes('send message') || aria.includes('enviar mensagem') || aria === 'send' || aria === 'enviar')
        && isInsideChatInput(el);
    };

    const isApproveBtn = (el) => {
      if (!el) return false;
      const text = normalize(getText(el));
      return text.includes('approve') || text.includes('aprovar') || text.includes('apply');
    };

    const getProjectId = () => {
      const m = String(window.location && window.location.pathname || '').match(/\/projects\/([a-z0-9-]+)/i);
      return m && m[1] ? String(m[1]).trim() : '';
    };

    const getPromptText = () => {
      const ed = document.querySelector('[contenteditable="true"][aria-label="Chat input"]');
      return String(ed && ed.textContent || '').replace(/\u00A0/g, ' ').replace(/\s+/g, ' ').trim();
    };

    const clearEditor = () => {
      try {
        const ed = document.querySelector('[contenteditable="true"][aria-label="Chat input"]');
        if (!ed) return;
        ed.innerHTML = '<p><br class="ProseMirror-trailingBreak"></p>';
        ed.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true }));
      } catch (_) {}
    };

    const fileToDataUrl = (file) => new Promise((res, rej) => {
      try {
        const r = new FileReader();
        r.onload = () => res(String(r.result || ''));
        r.onerror = () => rej(new Error('read_failed'));
        r.readAsDataURL(file);
      } catch (e) { rej(e); }
    });

    const collectAttachments = async () => {
      const form = document.querySelector('form#chat-input, form[id*="chat-input"]');
      if (!form) return { files: [], hasIndicators: false };
      const hasIndicators = !!form.querySelector('img[src^="blob:"], img[src^="data:image/"], [data-testid*="attachment" i]');
      const rawFiles = [];
      Array.from(form.querySelectorAll('input[type="file"]')).forEach(input => {
        const list = input && input.files;
        if (!list || !list.length) return;
        for (let i = 0; i < list.length; i++) { const f = list.item(i); if (f) rawFiles.push(f); }
      });
      if (!rawFiles.length) return { files: [], hasIndicators };
      const seen = new Set();
      const payload = [];
      for (const file of rawFiles) {
        const key = file.name + '::' + file.size + '::' + file.lastModified;
        if (seen.has(key)) continue;
        seen.add(key);
        try {
          const data = await fileToDataUrl(file);
          if (data) payload.push({ name: file.name || 'upload', content_type: file.type || 'application/octet-stream', data });
        } catch (_) {}
      }
      return { files: payload, hasIndicators };
    };

    const removeToast = () => { const t = document.getElementById(TOAST_ID); if (t) t.remove(); };
    const showToast = (msg, color) => {
      color = color || '#2563eb';
      removeToast();
      const t = document.createElement('div');
      t.id = TOAST_ID;
      t.style.cssText = 'position:fixed;top:16px;right:16px;z-index:2147483647;padding:9px 14px;border-radius:10px;background:rgba(2,6,23,0.95);border:1px solid ' + color + ';color:#e2e8f0;font:600 12px/1.4 system-ui,sans-serif;pointer-events:none;';
      t.textContent = String(msg || '');
      document.body.appendChild(t);
      setTimeout(function() {
        t.style.transition = 'opacity .22s,transform .22s';
        t.style.opacity = '0';
        t.style.transform = 'translateY(-4px)';
        setTimeout(function() { t.remove(); }, 230);
      }, 2400);
    };

    const isCurrentController = () => {
      const root = document.documentElement || document.body;
      return String(root && root.getAttribute(TOKEN_ATTR) || '') === controllerToken;
    };

    const isRetryable = (msg) => {
      const t = String(msg || '').toLowerCase();
      return t.includes('receiving end does not exist') || t.includes('could not establish connection') || t.includes('extension context invalidated');
    };

    const sendToBackground = (payload, timeoutMs) => new Promise(function(resolve) {
      timeoutMs = timeoutMs || 18000;
      let settled = false;
      let attempts = 0;
      const finish = (v) => { if (settled) return; settled = true; clearTimeout(tid); resolve(v); };
      const tid = setTimeout(function() { finish({ __timeout: true }); }, Math.max(1200, timeoutMs));
      const attempt = () => {
        attempts++;
        try {
          if (!(window.chrome && chrome.runtime && typeof chrome.runtime.sendMessage === 'function')) {
            finish({ __runtimeError: 'Runtime indisponível.' }); return;
          }
          chrome.runtime.sendMessage(payload, function(resp) {
            const err = chrome.runtime && chrome.runtime.lastError;
            if (err) {
              if (attempts < 2 && isRetryable(err.message)) { setTimeout(attempt, 300); return; }
              finish({ __runtimeError: err.message }); return;
            }
            finish(resp || { success: false, detail: 'Resposta vazia.' });
          });
        } catch (e) {
          const msg = String(e && e.message || e || '');
          if (attempts < 2 && isRetryable(msg)) { setTimeout(attempt, 300); return; }
          finish({ __runtimeError: msg });
        }
      };
      attempt();
    });

    const controller = { inFlight: false, skipUntil: 0, onClick: null, onKeydown: null, onSubmit: null, cleanup: null };

    const nativeFallback = (opts) => {
      opts = opts || {};
      controller.skipUntil = Date.now() + 1500;
      setTimeout(function() {
        try {
          if (opts.kind === 'approve') {
            const btn = (opts.sourceTarget && typeof opts.sourceTarget.click === 'function')
              ? opts.sourceTarget
              : document.querySelector('button[aria-label*="approve" i], button[title*="approve" i]');
            if (btn) { btn.click(); return; }
          }
          const sendBtn = document.getElementById('chatinput-send-message-button')
            || document.querySelector('button[aria-label*="send message" i]');
          if (sendBtn) { sendBtn.click(); return; }
          const form = document.querySelector('form#chat-input, form[id*="chat-input"]');
          if (form && form.requestSubmit) form.requestSubmit();
        } catch (_) {}
      }, 40);
    };

    const runAction = async (opts) => {
      opts = opts || {};
      const kind = opts.kind;
      if (!isCurrentController()) return;
      if (kind !== 'approve' && kind !== 'native-send') return;
      if (controller.inFlight) return;

      const projectId = getProjectId();
      if (!projectId) { showToast('Project ID não encontrado.', '#ef4444'); return; }

      let payload;
      if (kind === 'approve') {
        // Send approve action to backend
        payload = { action: 'ilimitadoAction', kind: 'approve', projectId };
      } else {
        const promptText = getPromptText();
        const attachments = await collectAttachments();
        const files = attachments.files;
        const hasIndicators = attachments.hasIndicators;

        if (hasIndicators && !files.length) {
          showToast('Anexo detectado — usando envio nativo.', '#f59e0b');
          nativeFallback(opts);
          return;
        }
        if (!promptText && !files.length) { showToast('Mensagem vazia.', '#f59e0b'); return; }

        // Send message to backend with captured data
        payload = { action: 'ilimitadoAction', kind: 'send', projectId, promptText, files };
      }

      controller.inFlight = true;
      showToast(kind === 'approve' ? 'Aplicando plano...' : 'Enviando via Ilimitado Lov...', '#2456F0');

      try {
        const resp = await sendToBackground(payload, 30000);
        if (resp && (resp.__timeout || resp.__runtimeError)) {
          showToast('Liberando envio nativo...', '#f59e0b');
          nativeFallback(opts);
          return;
        }
        if (!resp || !resp.success) { showToast((resp && resp.detail) || 'Falha no envio.', '#ef4444'); return; }
        if (kind === 'native-send') clearEditor();
        showToast(kind === 'approve' ? 'Plano aplicado! ✓' : 'Mensagem enviada! ✓', '#22c55e');
      } finally {
        controller.inFlight = false;
      }
    };

    controller.onClick = function(e) {
      if (Date.now() < controller.skipUntil) return;
      if (!isCurrentController()) { if (controller.cleanup) controller.cleanup(); return; }
      const base = getEventTarget(e);
      const target = base && base.closest && base.closest('button,[role="button"],a[role="button"]');
      if (!target) return;
      const approve = isApproveBtn(target);
      const send = !approve && isNativeSendBtn(target);
      if (!approve && !send) return;
      e.preventDefault(); e.stopPropagation();
      if (typeof e.stopImmediatePropagation === 'function') e.stopImmediatePropagation();
      runAction({ kind: approve ? 'approve' : 'native-send', sourceTarget: target });
    };

    controller.onKeydown = function(e) {
      if (Date.now() < controller.skipUntil) return;
      if (!isCurrentController()) { if (controller.cleanup) controller.cleanup(); return; }
      if (String(e && e.key || '').toLowerCase() !== 'enter') return;
      if (e.isComposing || e.shiftKey || e.ctrlKey || e.altKey || e.metaKey) return;
      const t = getEventTarget(e);
      if (!isInsideChatInput(t)) return;
      e.preventDefault(); e.stopPropagation();
      if (typeof e.stopImmediatePropagation === 'function') e.stopImmediatePropagation();
      runAction({ kind: 'native-send', sourceTarget: t });
    };

    controller.onSubmit = function(e) {
      if (Date.now() < controller.skipUntil) return;
      if (!isCurrentController()) { if (controller.cleanup) controller.cleanup(); return; }
      const form = getEventTarget(e) && getEventTarget(e).closest && getEventTarget(e).closest('form');
      if (!form || !form.matches || !form.matches('form#chat-input, form[id*="chat-input"]')) return;
      e.preventDefault(); e.stopPropagation();
      if (typeof e.stopImmediatePropagation === 'function') e.stopImmediatePropagation();
      runAction({ kind: 'native-send', sourceTarget: form });
    };

    window.addEventListener('click',   controller.onClick,   true);
    window.addEventListener('keydown', controller.onKeydown, true);
    window.addEventListener('submit',  controller.onSubmit,  true);

    controller.cleanup = function() {
      window.removeEventListener('click',   controller.onClick,   true);
      window.removeEventListener('keydown', controller.onKeydown, true);
      window.removeEventListener('submit',  controller.onSubmit,  true);
      removeToast();
      const root = document.documentElement || document.body;
      if (root && String(root.getAttribute(TOKEN_ATTR) || '') === controllerToken) {
        root.removeAttribute(TOKEN_ATTR);
      }
    };

    window[RUNTIME_KEY] = controller;
  });
}

// ── Lifecycle hooks ───────────────────────────────────────────────────────────

function ensureGuardOnAllLovableTabs() {
  chrome.tabs.query({}, (tabs) => {
    (Array.isArray(tabs) ? tabs : []).forEach((tab) => {
      const tabId = Number(tab && tab.id || 0);
      if (!Number.isFinite(tabId) || tabId <= 0) return;
      if (!isLovableUrl(tab && tab.url || '')) return;
      activateApproveGuard(tabId).then((ok) => setApproveGuardState(tabId, !!ok));
    });
  });
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
  ensureGuardOnAllLovableTabs();
});

chrome.runtime.onStartup.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
  ensureGuardOnAllLovableTabs();
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== 'complete') return;
  if (isLovableUrl(tab && tab.url || '')) {
    activateApproveGuard(tabId).then((ok) => setApproveGuardState(tabId, !!ok));
  } else if (hasApproveGuardState(tabId)) {
    setApproveGuardState(tabId, false);
  }
});

chrome.tabs.onActivated.addListener(async (activeInfo) => {
  try {
    const tab = await chrome.tabs.get(activeInfo.tabId);
    if (isLovableUrl(tab && tab.url || '')) {
      const ok = await activateApproveGuard(activeInfo.tabId);
      setApproveGuardState(activeInfo.tabId, !!ok);
    } else if (hasApproveGuardState(activeInfo.tabId)) {
      setApproveGuardState(activeInfo.tabId, false);
    }
  } catch (_) {}
});

chrome.tabs.onRemoved.addListener((tabId) => {
  if (hasApproveGuardState(tabId)) setApproveGuardState(tabId, false);
});

// ── 3. Message handlers — THIN CLIENT ─────────────────────────────────────────
// All actions are forwarded to the backend Edge Function (process-message).
// The background only acts as a bridge between the content script and the backend.

async function callProcessMessage(payload) {
  // Get license session token
  const storage = await new Promise(r => chrome.storage.local.get(['licenseSessionToken', 'authToken', 'lovable_token'], r));
  const sessionToken = storage.licenseSessionToken || '';
  const lovableToken = String(storage.authToken || storage.lovable_token || '').trim();
  
  if (!lovableToken || lovableToken.length < 20) {
    return { success: false, detail: 'Token não capturado ainda. Navegue no Lovable.dev primeiro.' };
  }
  
  if (!sessionToken) {
    return { success: false, detail: 'Licença não validada. Abra o painel lateral primeiro.' };
  }

  // Extract lovable_session_id from token JWT
  let lovableSessionId = null;
  try {
    const parts = lovableToken.split('.');
    if (parts.length === 3) {
      const jwtPayload = JSON.parse(atob(parts[1]));
      lovableSessionId = jwtPayload.user_id || jwtPayload.sub || null;
    }
  } catch (_) {}

  const body = {
    ...payload,
    lovable_token: lovableToken,
    lovable_session_id: lovableSessionId
  };

  try {
    const response = await fetch(`${SUPABASE_URL}/functions/v1/process-message`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'apikey': SUPABASE_ANON_KEY,
        'x-session-token': sessionToken
      },
      body: JSON.stringify(body)
    });

    if (response.ok || response.status === 202) {
      return { success: true, detail: 'Processado com sucesso.' };
    } else {
      let errorMsg = `HTTP ${response.status}`;
      try {
        const data = await response.json();
        errorMsg = data.message || data.detail || errorMsg;
      } catch (_) {}
      return { success: false, detail: errorMsg };
    }
  } catch (e) {
    return { success: false, detail: e.message };
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

  if (message.action === 'openUrl' && message.url) {
    chrome.tabs.create({ url: message.url });
    sendResponse({ success: true });
    return true;
  }

  // ── Unified action handler from ApproveGuard ──────────────────────────────
  if (message.action === 'ilimitadoAction') {
    (async () => {
      try {
        if (message.kind === 'approve') {
          const result = await callProcessMessage({
            action: 'approve',
            project_id: message.projectId,
          });
          sendResponse(result);
        } else if (message.kind === 'send') {
          const result = await callProcessMessage({
            message: message.promptText || null,
            project_id: message.projectId,
            files: message.files || undefined
          });
          sendResponse(result);
        } else {
          sendResponse({ success: false, detail: 'Ação desconhecida.' });
        }
      } catch (e) {
        sendResponse({ success: false, detail: e.message });
      }
    })();
    return true;
  }
});


// Bootstrap
ensureGuardOnAllLovableTabs();
