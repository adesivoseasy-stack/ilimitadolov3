// ============================================================
// ILIMITADO LOV Extension - v4.1.0 THIN CLIENT + REMOTE UI
// ============================================================
// Shell mínimo: carrega o HTML remoto num iframe e expõe
// bridge para o iframe se comunicar com as APIs do Chrome
// e com o backend (process-message Edge Function).
//
// O iframe NÃO tem acesso direto a chrome.*, cookies, storage.
// Tudo passa pela bridge via postMessage.
// ============================================================

const EXTENSION_VERSION = '4.1.0';
console.log(`🚀 Ilimitado Lov Shell v${EXTENSION_VERSION} iniciando...`);

const SUPABASE_URL = 'https://rmetppilvfrxosvxzhgj.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJtZXRwcGlsdmZyeG9zdnh6aGdqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzAwNjE2MzgsImV4cCI6MjA4NTYzNzYzOH0.9ClXH2tomnJAGf0BSTAsJ7v4DTfnKQ8DDcrFj8mbqxY';

const iframe = document.getElementById('remoteUI');
const loadingShell = document.getElementById('loadingShell');

// ── Load remote UI ─────────────────────────────────────────────────────────────
async function loadRemoteUI() {
  try {
    const url = `${SUPABASE_URL}/functions/v1/get-extension-front`;
    const res = await fetch(url, {
      headers: {
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'apikey': SUPABASE_ANON_KEY
      }
    });

    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const html = await res.text();

    // Inject bridge script before </body>
    const bridgeScript = `
<script>
// ── Bridge API: comunicação com o shell da extensão ─────────────────────────
// O iframe chama window.bridge.* e recebe respostas via postMessage.
(function() {
  let _callId = 0;
  const _pending = {};

  window.addEventListener('message', (e) => {
    if (e.data && e.data.__bridgeResponse && _pending[e.data.callId]) {
      const { resolve, reject } = _pending[e.data.callId];
      delete _pending[e.data.callId];
      if (e.data.error) reject(new Error(e.data.error));
      else resolve(e.data.result);
    }
  });

  function bridgeCall(method, args) {
    return new Promise((resolve, reject) => {
      const callId = ++_callId;
      _pending[callId] = { resolve, reject };
      window.parent.postMessage({ __bridgeCall: true, callId, method, args }, '*');
    });
  }

  window.bridge = {
    // License
    validateLicense:   (key)    => bridgeCall('validateLicense', { key }),
    getStoredLicense:  ()       => bridgeCall('getStoredLicense', {}),
    storeLicense:      (key, token) => bridgeCall('storeLicense', { key, token }),
    removeLicense:     ()       => bridgeCall('removeLicense', {}),
    revalidateLicense: ()       => bridgeCall('revalidateLicense', {}),

    // Auth data (cookies from lovable.dev)
    getAuthData:       ()       => bridgeCall('getAuthData', {}),

    // Project
    getProjectId:      ()       => bridgeCall('getProjectId', {}),

    // Send message to backend (process-message)
    sendMessage:       (payload) => bridgeCall('sendMessage', payload),

    // Publish / Approve
    publishProject:    (projectId) => bridgeCall('sendMessage', { action: 'publish', project_id: projectId }),
    approveProject:    (projectId) => bridgeCall('sendMessage', { action: 'approve', project_id: projectId }),

    // Support info
    getSupportInfo:    ()       => bridgeCall('getSupportInfo', {}),

    // Open URL in new tab
    openUrl:           (url)    => bridgeCall('openUrl', { url }),

    // Storage (chrome.storage.local)
    storage: {
      get: (keys) => bridgeCall('storageGet', { keys }),
      set: (data) => bridgeCall('storageSet', { data }),
    },

    // Extension version
    version: '${EXTENSION_VERSION}',

    // Suggestions from Lovable page
    getSuggestions:    ()       => bridgeCall('getSuggestions', {}),
  };

  console.log('[Bridge] Ready v${EXTENSION_VERSION}');
})();
<\/script>`;

    const injectedHtml = html.replace('</body>', bridgeScript + '\n</body>');

    // Load into iframe via srcdoc
    iframe.srcdoc = injectedHtml;
    iframe.onload = () => {
      loadingShell.classList.add('hidden');
      console.log('✅ Remote UI loaded');
    };

  } catch (err) {
    console.error('❌ Failed to load remote UI:', err);
    loadingShell.innerHTML = `
      <div style="color:#ef4444;font-size:13px;text-align:center">
        <p>Erro ao carregar interface</p>
        <p style="color:#666;margin-top:8px;font-size:11px">${err.message}</p>
        <button onclick="location.reload()" style="margin-top:16px;padding:8px 16px;border-radius:8px;background:#2456F0;color:white;border:none;cursor:pointer;font-size:12px">Tentar novamente</button>
      </div>`;
  }
}

// ── Bridge message handler ─────────────────────────────────────────────────────
// The iframe sends postMessage calls, we handle them here with chrome.* APIs.

let cachedHwid = null;

async function generateHWID() {
  if (cachedHwid) return cachedHwid;
  const stored = await chrome.storage.local.get(['hwid']);
  if (stored.hwid) { cachedHwid = stored.hwid; return stored.hwid; }
  const components = [
    navigator.userAgent, navigator.language, navigator.platform,
    screen.width + 'x' + screen.height, screen.colorDepth,
    new Date().getTimezoneOffset(), navigator.hardwareConcurrency || 'unknown'
  ];
  const hashBuffer = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(components.join('|')));
  cachedHwid = Array.from(new Uint8Array(hashBuffer)).map(b => b.toString(16).padStart(2, '0')).join('');
  await chrome.storage.local.set({ hwid: cachedHwid });
  return cachedHwid;
}

async function getAuthData() {
  try {
    const cookies = await chrome.cookies.getAll({ domain: 'lovable.dev' });
    let token = null, sessionId = null;
    for (const cookie of cookies) {
      if (cookie.name === 'lovable-session-id.id' && !token) token = cookie.value;
      if (cookie.name === 'sb-api-auth-token' && !token) {
        try { const p = JSON.parse(decodeURIComponent(cookie.value)); token = p.access_token || p[0]?.access_token || cookie.value; } catch (_) { token = cookie.value; }
      }
      if (cookie.name === 'lovable-session-id.id' && !sessionId) {
        try { const parts = cookie.value.split('.'); if (parts.length === 3) { const p = JSON.parse(atob(parts[1])); sessionId = p.user_id || p.sub; } } catch (_) {}
      }
      if (!sessionId && cookie.name.includes('session')) {
        try { const p = JSON.parse(decodeURIComponent(cookie.value)); sessionId = p.session_id || p[0]?.session_id; } catch (_) {}
      }
    }
    return { token, sessionId };
  } catch (_) { return { token: null, sessionId: null }; }
}

async function getProjectFromActiveTab() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.url) return null;
    const m = tab.url.match(/lovable\.dev\/projects\/([a-f0-9-]+)/);
    if (m) return m[1];
    const sm = tab.url.match(/([a-f0-9-]+)\.lovableproject\.com/);
    if (sm) return sm[1];
    return null;
  } catch (_) { return null; }
}

async function getSuggestions() {
  try {
    const tabs = await new Promise(r => chrome.tabs.query({ url: 'https://lovable.dev/*' }, r));
    if (!tabs.length) return [];
    const results = await chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      func: () => {
        const container = document.querySelector('[data-horizontal-scroll="true"]');
        if (!container) return [];
        const btns = container.querySelectorAll('button');
        const out = [];
        btns.forEach(btn => {
          const deepest = btn.querySelector('font font') || btn.querySelector('font') || btn;
          const label = deepest.textContent?.trim();
          if (!label || label.length < 2 || label.length > 80) return;
          let fullText = label;
          try {
            const fk = Object.keys(btn).find(k => k.startsWith('__reactFiber') || k.startsWith('__reactInternalInstance'));
            if (fk) {
              let fiber = btn[fk]; let d = 0;
              while (fiber && d < 10) {
                const props = fiber.memoizedProps || fiber.pendingProps;
                if (props?.onClick) { const s = props.onClick.toString(); const m = s.match(/"([^"]{15,300})"/); if (m) { fullText = m[1]; break; } }
                fiber = fiber.return; d++;
              }
            }
          } catch (_) {}
          out.push({ label, fullText });
        });
        return out;
      }
    });
    return results?.[0]?.result || [];
  } catch (_) { return []; }
}

// Handle bridge calls from iframe
window.addEventListener('message', async (e) => {
  if (!e.data || !e.data.__bridgeCall) return;
  const { callId, method, args } = e.data;

  let result = null;
  let error = null;

  try {
    switch (method) {

      case 'validateLicense': {
        await generateHWID();
        const res = await fetch(`${SUPABASE_URL}/functions/v1/validate-license`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${SUPABASE_ANON_KEY}`, 'apikey': SUPABASE_ANON_KEY },
          body: JSON.stringify({ license_key: args.key })
        });
        result = await res.json();
        break;
      }

      case 'getStoredLicense': {
        const s = await chrome.storage.local.get(['licenseKey', 'licenseSessionToken']);
        result = { licenseKey: s.licenseKey || null, sessionToken: s.licenseSessionToken || null };
        break;
      }

      case 'storeLicense': {
        await chrome.storage.local.set({ licenseKey: args.key, licenseSessionToken: args.token });
        result = { ok: true };
        break;
      }

      case 'removeLicense': {
        await chrome.storage.local.remove(['licenseKey', 'licenseSessionToken']);
        result = { ok: true };
        break;
      }

      case 'revalidateLicense': {
        const stored = await chrome.storage.local.get(['licenseKey', 'licenseSessionToken']);
        if (!stored.licenseKey) { result = { valid: false, message: 'Nenhuma licença ativada' }; break; }
        const res = await fetch(`${SUPABASE_URL}/functions/v1/validate-license`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${SUPABASE_ANON_KEY}`, 'apikey': SUPABASE_ANON_KEY },
          body: JSON.stringify({ license_key: stored.licenseKey })
        });
        const r = await res.json();
        if (r.status === 'valid') {
          await chrome.storage.local.set({ licenseSessionToken: r.session_token });
          result = { valid: true, session_token: r.session_token, days_remaining: r.days_remaining, hours_remaining: r.hours_remaining, license_id: r.license_id };
        } else {
          result = { valid: false, message: r.message };
        }
        break;
      }

      case 'getAuthData': {
        result = await getAuthData();
        break;
      }

      case 'getProjectId': {
        result = await getProjectFromActiveTab();
        break;
      }

      case 'sendMessage': {
        // Get session token and auth
        const stored = await chrome.storage.local.get(['licenseSessionToken']);
        const auth = await getAuthData();
        const projectId = args.project_id || await getProjectFromActiveTab();

        if (!projectId) { error = 'Abra um projeto no Lovable.dev primeiro'; break; }

        const payload = {
          ...args,
          project_id: projectId,
          lovable_token: auth.token,
          lovable_session_id: auth.sessionId,
        };

        const res = await fetch(`${SUPABASE_URL}/functions/v1/process-message`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
            'apikey': SUPABASE_ANON_KEY,
            'x-session-token': stored.licenseSessionToken || ''
          },
          body: JSON.stringify(payload)
        });

        if (res.ok || res.status === 202) {
          result = { ok: true, status: res.status };
        } else {
          let msg = `HTTP ${res.status}`;
          try { const d = await res.json(); msg = d.message || msg; } catch (_) {}
          error = msg;
        }
        break;
      }

      case 'getSupportInfo': {
        try {
          const res = await fetch(`${SUPABASE_URL}/functions/v1/get-support-info`, {
            headers: { 'Authorization': `Bearer ${SUPABASE_ANON_KEY}`, 'apikey': SUPABASE_ANON_KEY }
          });
          result = res.ok ? await res.json() : {};
        } catch (_) { result = {}; }
        break;
      }

      case 'openUrl': {
        chrome.runtime.sendMessage({ action: 'openUrl', url: args.url });
        result = { ok: true };
        break;
      }

      case 'storageGet': {
        result = await chrome.storage.local.get(args.keys);
        break;
      }

      case 'storageSet': {
        await chrome.storage.local.set(args.data);
        result = { ok: true };
        break;
      }

      case 'getSuggestions': {
        result = await getSuggestions();
        break;
      }

      default:
        error = `Unknown bridge method: ${method}`;
    }
  } catch (err) {
    error = err.message || 'Bridge error';
  }

  // Send response back to iframe
  iframe.contentWindow?.postMessage({
    __bridgeResponse: true,
    callId,
    result,
    error
  }, '*');
});

// ── Initialize ─────────────────────────────────────────────────────────────────
generateHWID();
loadRemoteUI();
