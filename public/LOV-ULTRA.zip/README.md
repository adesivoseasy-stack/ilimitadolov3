# Pulse Coding

Extensao de Chrome para **gerenciamento inteligente de creditos** no [Lovable](https://lovable.dev). Otimize cada prompt enviado, acompanhe seu uso diario e interaja com seus projetos sem se preocupar com limites.

## O que faz

1. **Licenca online** — a extensao so funciona com chave valida. Plano e validade sao checados no servidor (cache de 1h, com revalidacao no toggle). A primeira ativacao vincula a chave ao email da sua conta Lovable.
2. **Otimizacao de prompts** — quando ligado, cada prompt enviado ao Lovable e otimizado automaticamente pelo nosso servidor, garantindo o melhor uso dos seus creditos.
3. **Upload inteligente de imagens** — anexou imagem? A extensao faz o processamento necessario e cola a URL dentro da mensagem, sem custo adicional de creditos.
4. **Badge na pagina** — indicador `PULSE ON/OFF` no canto, mostra `NO LIC` em vermelho se nao tem licenca.
5. **Toast de erro com retry** — falha de stream/rate limit mostra notificacao com botao de tentar de novo.
6. **Estatisticas locais** — contador de prompts e erros no popup, com grafico dos ultimos 7 dias.

## Instalacao (modo desenvolvedor)

1. Baixe ou clone esta pasta.
2. Abra `chrome://extensions/`.
3. Ative **Modo do desenvolvedor**.
4. **Carregar sem compactacao** -> selecione a pasta `lovable-booster`.
5. Clique no icone da extensao e cole sua chave de licenca.

## Uso

### Ativar a licenca
- Clique no icone -> cole a chave -> **Ativar**.
- A primeira validacao vincula sua chave ao email da sessao do Lovable. Se voce ainda nao abriu o Lovable, ela e validada sem vinculo; assim que voce acessar, e vinculada automaticamente.
- Tentar usar a mesma chave em outra conta retorna `Licenca vinculada a outra conta`.

### Ligar / desligar
- Botao grande do popup, **ou**
- Badge `PULSE` na pagina do Lovable, **ou**
- Atalho `Ctrl+Shift+L` (`Cmd+Shift+L` no Mac), remapeavel em `chrome://extensions/shortcuts`.

Sem licenca valida o toggle simplesmente nao liga.

## Arquitetura

- **Service worker** ([background.js](background.js)) — fonte de verdade do estado. Valida licenca, cacheia resultado, revalida automaticamente.
- **Content script** ([content/content.js](content/content.js)) — injeta o badge e o script de otimizacao na pagina.
- **Inject script** ([content/inject.js](content/inject.js)) — faz patch de `window.fetch` para otimizar prompts automaticamente.
- **Proxy** — servidor intermediario que processa e otimiza os prompts antes de enviar ao Lovable.

## Privacidade

- Dados locais (`chrome.storage.local`): chave de licenca, hash da chave, email do Lovable, contadores de uso.
- Dados enviados ao servidor: chave + email (para validacao), imagens (para processamento).
- Dados que **nao** saem da maquina: textos dos prompts, IDs de projeto, headers de telemetria.
- Nao ha analytics. Nao ha telemetria.

## Estrutura

```
lovable-booster/
|-- manifest.json
|-- background.js
|-- content/
|   |-- content.js
|   |-- content.css
|   |-- inject.js
|-- popup/
|   |-- popup.html
|   |-- popup.css
|   |-- popup.js
|-- options/
|   |-- options.html
|   |-- options.css
|   |-- options.js
|-- lib/
|   |-- constants.js
|   |-- license.js
|   |-- storage.js
|-- icons/
```

## Licenca

Uso interno. Distribuicao apenas com chave de licenca valida.
