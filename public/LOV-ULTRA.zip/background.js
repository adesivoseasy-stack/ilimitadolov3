import { getSettings, setSettings } from './lib/storage.js';
import {
  getLicenseState,
  validateLicense,
  clearLicense,
  emptyLicenseState,
} from './lib/license.js';

// ============================================================
// Anti-tampering: garante que estamos rodando no contexto correto
// de uma extensão Chrome (não em copy/repackage por terceiros).
// ============================================================
const _PULSE_RUNTIME_OK = (() => {
  try {
    if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.id) return false;
    const m = chrome.runtime.getManifest?.();
    if (!m) return false;
    // Nome da extensão precisa bater
    if (m.name !== 'Ilimitado Lov') return false;
    // Service worker precisa ser MV3
    if (m.manifest_version !== 3) return false;
    return true;
  } catch (_) {
    return false;
  }
})();

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!_PULSE_RUNTIME_OK) {
    sendResponse({ ok: false, error: 'runtime invalid' });
    return;
  }
  return _PULSE_handler(msg, _sender, sendResponse);
});

function _PULSE_handler(msg, _sender, sendResponse) {
  (async () => {
    try {
      switch (msg.type) {
        case 'GET_SETTINGS':
          // Check local de expiração antes de responder
          await checkLocalExpiry();
          sendResponse(await getSettings());
          break;

        case 'SET_SETTINGS': {
          const updated = await setSettings(msg.updates || {});
          updateBadge(updated);
          sendResponse(updated);
          break;
        }

        case 'TOGGLE_ENABLED': {
          const cur = await getSettings();
          // Desligar sempre permitido
          if (cur.enabled) {
            const updated = await setSettings({ enabled: false });
            updateBadge(updated);
            sendResponse(updated);
            break;
          }
          // Tentando LIGAR — validações em sequência:
          // 1) Licença válida
          const state = await getLicenseState({ force: true });
          if (state.status !== 'valid') {
            const updated = await setSettings({ enabled: false });
            updateBadge(updated);
            sendResponse({ ...updated, error: state.error || 'Sem licença válida' });
            break;
          }
          // 2) Aba ativa precisa ser um projeto Lovable
          const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
          const url = tab?.url || '';
          const isProjectUrl = /https:\/\/lovable\.dev\/projects\/[a-f0-9-]+/i.test(url);
          if (!tab?.id || !isProjectUrl) {
            sendResponse({
              ...cur,
              error: 'Abra um projeto Lovable em lovable.dev/projects/<id> antes de ativar.',
            });
            break;
          }
          // 3) Content script precisa estar vivo (responde a PING)
          let pingOk = false;
          try {
            const pingPromise = chrome.tabs.sendMessage(tab.id, { type: 'PING' });
            const timeoutPromise = new Promise((_, reject) =>
              setTimeout(() => reject(new Error('ping-timeout')), 1500)
            );
            const pong = await Promise.race([pingPromise, timeoutPromise]);
            pingOk = !!pong?.ok;
          } catch (_) {
            pingOk = false;
          }
          if (!pingOk) {
            sendResponse({
              ...cur,
              error: 'Recarregue a aba do Lovable (F5) e tente novamente.',
            });
            break;
          }
          // Tudo OK — liga
          const updated = await setSettings({ enabled: true });
          updateBadge(updated);
          sendResponse(updated);
          break;
        }

        case 'VALIDATE_LICENSE': {
          // Aceita key opcional pra ativar uma nova; se não vier, revalida a atual.
          const cur = await getSettings();
          const key = msg.key !== undefined ? msg.key : cur.licenseKey;
          const email = msg.email !== undefined ? msg.email : cur.userEmail;
          if (msg.key !== undefined && msg.key !== cur.licenseKey) {
            await setSettings({ licenseKey: key, licenseState: emptyLicenseState() });
          }
          const state = await validateLicense(key, email);
          if (state.status !== 'valid') {
            const updated = await setSettings({ enabled: false });
            updateBadge(updated);
          }
          sendResponse(state);
          break;
        }

        case 'GET_LICENSE_STATE': {
          const state = await getLicenseState({ force: !!msg.force });
          sendResponse(state);
          break;
        }

        case 'CLEAR_LICENSE': {
          await clearLicense();
          const updated = await setSettings({ enabled: false });
          updateBadge(updated);
          sendResponse(updated);
          break;
        }

        case 'LOG_USER_EMAIL': {
          const cur = await getSettings();
          const incoming = msg.email || '';
          if (incoming && incoming !== cur.userEmail) {
            await setSettings({ userEmail: incoming });
            // Se já tem licença, força revalidação pra fazer bind do email.
            if (cur.licenseKey) {
              validateLicense(cur.licenseKey, incoming).catch(() => {});
            }
          }
          sendResponse({ ok: true });
          break;
        }

        case 'SAVE_LOVABLE_TOKEN': {
          const token = msg.token || '';
          if (token) {
            await setSettings({ lovableToken: token, lovableTokenAt: Date.now() });
          }
          sendResponse({ ok: true });
          break;
        }

        case 'SAVE_LOVABLE_WORKSPACE_ID': {
          const wsId = msg.workspaceId || '';
          if (wsId) {
            await setSettings({ lovableWorkspaceId: wsId });
          }
          sendResponse({ ok: true });
          break;
        }

        case 'SAVE_LOVABLE_CASTLE_TOKEN': {
          const ct = msg.token || '';
          if (ct) {
            await setSettings({ lovableCastleToken: ct, lovableCastleTokenAt: Date.now() });
          }
          sendResponse({ ok: true });
          break;
        }

        case 'SAVE_LOVABLE_SESSION_HEADERS': {
          const updates = {};
          if (msg.sessionId) updates.lovableSessionId = msg.sessionId;
          if (msg.gitSha) updates.lovableClientGitSha = msg.gitSha;
          if (Object.keys(updates).length > 0) await setSettings(updates);
          sendResponse({ ok: true });
          break;
        }

        case 'GET_ACTIVE_PROJECT_ID': {
          const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
          const url = tab?.url || '';
          const m = /https:\/\/lovable\.dev\/projects\/([a-f0-9-]+)/i.exec(url);
          sendResponse({ projectId: m ? m[1] : null, url });
          break;
        }

        case 'CLEAR_CHAT_HISTORY': {
          // Sobrescreve direto via storage.local.set pra contornar o deepMerge
          // (que não consegue remover chaves de sub-objetos).
          const cur = await getSettings();
          const all = { ...(cur.tryToFixHistory || {}) };
          if (msg.projectId) {
            delete all[msg.projectId];
          } else {
            // sem projectId → limpa tudo
            Object.keys(all).forEach((k) => delete all[k]);
          }
          await chrome.storage.local.set({ settings: { ...cur, tryToFixHistory: all } });
          sendResponse({ ok: true, tryToFixHistory: all });
          break;
        }

        case 'LOG_INTEL': {
          const cur = await getSettings();
          await setSettings({ intel: { ...cur.intel, ...(msg.data || {}) } });
          sendResponse({ ok: true });
          break;
        }

        case 'LOG_FEATURE_FLAGS':
          await setSettings({ featureFlags: msg.flags || {} });
          sendResponse({ ok: true });
          break;

        case 'LOG_PROMPT': {
          const cur = await getSettings();
          const today = new Date().toISOString().slice(0, 10);
          const daily = { ...(cur.stats?.daily || {}) };
          daily[today] = (daily[today] || 0) + 1;
          // Keep only last 30 days to avoid bloating storage
          const keys = Object.keys(daily).sort();
          if (keys.length > 30) {
            keys.slice(0, keys.length - 30).forEach(k => delete daily[k]);
          }
          await setSettings({
            stats: {
              ...cur.stats,
              promptCount: (cur.stats?.promptCount || 0) + 1,
              lastPromptAt: Date.now(),
              daily,
            },
          });
          sendResponse({ ok: true });
          break;
        }

        case 'LOG_ERROR': {
          const cur = await getSettings();
          await setSettings({
            stats: { ...cur.stats, errorCount: (cur.stats?.errorCount || 0) + 1 },
          });
          sendResponse({ ok: true });
          break;
        }

        case 'RESET_STATS': {
          const updated = await setSettings({
            stats: { promptCount: 0, errorCount: 0, lastPromptAt: 0 },
          });
          sendResponse(updated);
          break;
        }

        case 'OPEN_OPTIONS':
          chrome.runtime.openOptionsPage();
          sendResponse({ ok: true });
          break;

        default:
          sendResponse({ ok: false, error: 'unknown: ' + msg.type });
      }
    } catch (e) {
      console.error('[PULSE bg]', e);
      sendResponse({ ok: false, error: e.message });
    }
  })();
  return true;
}

function updateBadge(settings) {
  try {
    const enabled = !!settings?.enabled;
    const status = settings?.licenseState?.status;
    if (status && status !== 'valid' && status !== 'unknown') {
      chrome.action.setBadgeText({ text: '!' });
      chrome.action.setBadgeBackgroundColor({ color: '#ef4444' });
      chrome.action.setBadgeTextColor?.({ color: '#ffffff' });
      return;
    }
    chrome.action.setBadgeText({ text: enabled ? 'on' : 'off' });
    chrome.action.setBadgeBackgroundColor({ color: enabled ? '#00CC82' : '#CC2222' });
    chrome.action.setBadgeTextColor?.({ color: '#ffffff' });
  } catch (_) {}
}

// ============================================================
// Verificação local de expiração (sem depender do servidor)
// ============================================================
async function checkLocalExpiry() {
  const cur = await getSettings();
  const expiresAt = cur.licenseState?.expiresAt;
  if (!expiresAt) return; // sem data = sem expiração local

  const now = Date.now();
  const expiresMs = new Date(expiresAt).getTime();
  if (Number.isNaN(expiresMs)) return;

  if (now >= expiresMs) {
    // EXPIROU — revoga imediatamente
    console.log('[PULSE bg] license expired locally, revoking');
    const expired = {
      ...emptyLicenseState(),
      status: 'expired',
      error: 'Licença expirada',
      lastChecked: now,
    };
    const updated = await setSettings({
      enabled: false,
      licenseState: expired,
    });
    updateBadge(updated);
    return true; // expirou
  }

  // Se falta menos de 2h, agenda alarm pra checar a cada 5 min
  const remaining = expiresMs - now;
  if (remaining < 2 * 3600 * 1000) {
    chrome.alarms?.create('license-expiry-watch', { periodInMinutes: 5 });
  }

  return false;
}

// Side panel: clique no ícone da extensão abre o painel lateral direito.
try {
  chrome.sidePanel?.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
} catch (_) {}

chrome.runtime.onInstalled.addListener(async () => {
  const s = await getSettings();
  updateBadge(s);
  await checkLocalExpiry();
  try { chrome.sidePanel?.setPanelBehavior({ openPanelOnActionClick: true }); } catch (_) {}
  // Re-validação silenciosa em background a cada 30 min.
  chrome.alarms?.create('license-revalidate', { periodInMinutes: 30 });
});

chrome.runtime.onStartup?.addListener(async () => {
  const s = await getSettings();
  updateBadge(s);
  await checkLocalExpiry();
  try { chrome.sidePanel?.setPanelBehavior({ openPanelOnActionClick: true }); } catch (_) {}
  chrome.alarms?.create('license-revalidate', { periodInMinutes: 30 });
});

chrome.alarms?.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'license-expiry-watch') {
    // Check rápido local — sem bater no servidor
    const expired = await checkLocalExpiry();
    if (expired) {
      // Para o watch, já expirou
      chrome.alarms?.clear('license-expiry-watch');
    }
    return;
  }

  if (alarm.name !== 'license-revalidate') return;

  // Primeiro: check local (instantâneo, sem rede)
  const localExpired = await checkLocalExpiry();
  if (localExpired) return; // já revogou

  // Depois: revalida com o servidor
  const cur = await getSettings();
  if (!cur.licenseKey) return;
  const state = await validateLicense(cur.licenseKey, cur.userEmail).catch(() => null);
  if (state && state.status !== 'valid') {
    const updated = await setSettings({ enabled: false });
    updateBadge(updated);
  } else {
    updateBadge(await getSettings());
  }
});

chrome.commands?.onCommand.addListener(async (command) => {
  if (command !== 'toggle-enabled') return;
  // Reusa a mesma lógica do TOGGLE_ENABLED.
  const cur = await getSettings();
  if (!cur.enabled) {
    const state = await getLicenseState({ force: true });
    if (state.status !== 'valid') {
      updateBadge(await setSettings({ enabled: false }));
      return;
    }
  }
  updateBadge(await setSettings({ enabled: !cur.enabled }));
});
