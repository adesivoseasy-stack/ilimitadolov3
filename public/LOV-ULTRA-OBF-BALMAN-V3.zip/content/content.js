(function () {
  'use strict';

  // ============================================================
  // Domain lock — content script só inicializa em lovable.dev.
  // Camada extra de defesa contra cópia/re-package em outro domínio.
  // ============================================================
  if (!/(^|\.)lovable\.dev$/i.test(location.hostname)) {
    return;
  }

  // ============================================================
  // Endpoint de otimizacao (dominio fixo + nginx + Let's Encrypt).
  // ============================================================
  const PROXY_BASE = atob("aHR0cHM6Ly93dmVsY2VmZ2lobHhjbnJtc2x1bC5zdXBhYmFzZS5jby9mdW5jdGlvbnMvdjE=");

  const STATE = {
    active: false,
    licenseValid: false,
    licenseHash: null,
    licenseKey: null,
    userEmail: null,
    config: null,
    badge: null,
    toast: null,
    panelHost: null,
    panelDiv: null,
    panelOpen: false,
  };

  init();

  async function init() {
    const settings = await sendMessage({ type: 'GET_SETTINGS' });
    STATE.licenseValid = settings?.licenseState?.status === 'valid';
    STATE.licenseHash = settings?.licenseState?.licenseHash || null;
    STATE.licenseKey = settings?.licenseKey || null;
    STATE.userEmail = settings?.userEmail || null;
    STATE.config = settings?.licenseState?.config || settings?.config || null;
    STATE.active = !!settings?.enabled && STATE.licenseValid;

    console.log('[PULSE content] init — active:', STATE.active, 'license:', STATE.licenseValid ? 'valid' : 'invalid', 'email:', STATE.userEmail || 'none');

    bindIncomingMessages();
    bindStorageChanges();
    bindExtensionMessages();
    setupRebrand();
    setupAnexosCleanup();
    setupPlanWatcher();
    // inject.js agora é injetado pelo manifest (world:MAIN, document_start),
    // garantindo que nosso patch de fetch rode ANTES do bundle da Lovable
    // pegar uma referência ao window.fetch original.
    announceActive();
  }

  /* ============================================================
     Proxy Transform Handler
     Chamado pelo inject.js (MAIN world) via postMessage.
     Roda no ISOLATED world → usa host_permissions da extensão,
     ignorando qualquer CSP da página.
     ============================================================ */
  async function handleTransformRequest(data) {
    const { id, body, uploadedAssets } = data;
    const endpoint = PROXY_BASE + '/api/v1/lovable/transform';

    // Usa STATE.licenseKey e STATE.userEmail como fonte primária (sempre frescos),
    // porque inject.js pode ter _licenseKey=null por race condition no startup.
    const licenseKey = STATE.licenseKey || data.licenseKey || null;
    const email = STATE.userEmail || data.email || null;

    console.log('[PULSE content] transform request → proxy:', PROXY_BASE,
      'key:', licenseKey ? '***' + licenseKey.slice(-4) : 'MISSING',
      'email:', email || 'MISSING');

    if (!licenseKey) {
      console.error('[PULSE content] no license key available!');
      window.postMessage({
        type: 'LOVABLE_TRANSFORM_RESULT',
        id,
        action: 'pass-through',
        error: 'Sem licenseKey — verifique a ativação da licença',
      }, '*');
      return;
    }

    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          licenseKey,
          email,
          body,
          uploadedAssets,
        }),
      });

      if (!res.ok) {
        const errText = await res.text().catch(() => '');
        console.warn('[PULSE content] proxy error:', res.status, errText);
        window.postMessage({
          type: 'LOVABLE_TRANSFORM_RESULT',
          id,
          action: 'pass-through',
          error: `Proxy HTTP ${res.status}: ${errText.slice(0, 120)}`,
        }, '*');
        return;
      }

      const result = await res.json();
      console.log('[PULSE content] proxy response:', result.action || 'transform', result.body ? '(body present)' : '(no body)');

      window.postMessage({
        type: 'LOVABLE_TRANSFORM_RESULT',
        id,
        action: result.action || null,
        body: result.body || null,
        error: result.error || null,
      }, '*');
    } catch (e) {
      console.error('[PULSE content] proxy unreachable:', e.message);
      window.postMessage({
        type: 'LOVABLE_TRANSFORM_RESULT',
        id,
        action: 'pass-through',
        error: 'Proxy inacessível: ' + e.message,
      }, '*');
    }
  }

  // Esconde blocos de instrucao injetados no chat, mantendo so o texto original.
  function setupAnexosCleanup() {
    const MARKER = '[ANEXOS';

    function hideLeakedComments(root) {
      if (!root || root.nodeType !== Node.ELEMENT_NODE) return;

      const TOGGLES = ['show more', 'show less', 'mostrar mais', 'mostrar menos', 'ver mais', 'ver menos'];
      const EXPANDS = ['show more', 'mostrar mais', 'ver mais'];
      const COLLAPSES = ['show less', 'mostrar menos', 'ver menos'];

      const blockquotes = root.querySelectorAll('blockquote');
      for (const bq of blockquotes) {
        const bqText = bq.textContent || '';
        // Detecta blockquotes com instrucoes internas (markers atuais + legado)
        if (!bqText.includes('PULSE-') && !bqText.includes('Pulse Coding Mode') &&
            !bqText.includes('LVFE-') && !bqText.includes('Visual Edits Mode')) continue;
        bq.style.display = 'none';

        // Esconde markers antes do blockquote
        let prev = bq.previousElementSibling;
        while (prev) {
          const pt = prev.textContent || '';
          if (pt.includes('[PULSE-INI]') || pt.includes('[PULSE-FIM]') ||
              pt.includes('[LVFE-INI]') || pt.includes('[LVFE-FIM]')) {
            prev.style.display = 'none';
          }
          if (pt.includes('[PULSE-INI]') || pt.includes('[LVFE-INI]')) break;
          prev = prev.previousElementSibling;
        }
        // Esconde markers depois do blockquote
        let next = bq.nextElementSibling;
        if (next && ((next.textContent || '').includes('[PULSE-FIM]') ||
            (next.textContent || '').includes('[LVFE-FIM]'))) {
          next.style.display = 'none';
        }

        let bubble = null;
        let n = bq.parentElement;
        for (let i = 0; i < 6 && n && n.tagName !== 'BODY'; i++) {
          const has = Array.from(n.querySelectorAll('button')).some((btn) =>
            TOGGLES.includes((btn.textContent || '').trim().toLowerCase()),
          );
          if (has) { bubble = n; break; }
          n = n.parentElement;
        }
        if (!bubble) continue;

        if (!bubble.dataset.pcPulseBadged) {
          bubble.dataset.pcPulseBadged = '1';
          const badge = document.createElement('div');
          badge.className = 'pc-pulse-tag';
          badge.innerHTML = '<span class="pc-pulse-dot">✦</span><span>LOV 3 IA</span>';
          badge.title = 'Processado pela LOV 3';
          bubble.parentElement?.insertBefore(badge, bubble);
        }

        bubble.querySelectorAll('button').forEach((btn) => {
          const txt = (btn.textContent || '').trim().toLowerCase();
          if (EXPANDS.includes(txt)) {
            if (!btn.dataset.pcClicked) {
              btn.dataset.pcClicked = '1';
              try { btn.click(); } catch (_) {}
            }
            btn.style.display = 'none';
          } else if (COLLAPSES.includes(txt)) {
            btn.style.display = 'none';
          }
        });
      }
    }

    function clean(root) {
      if (!root || root.nodeType !== Node.ELEMENT_NODE) return;
      const hrs = root.querySelectorAll('hr');
      hrs.forEach((hr) => {
        const parent = hr.parentElement;
        if (!parent) return;
        let foundMarker = false;
        let n = parent.firstChild;
        while (n && n !== hr) {
          if ((n.textContent || '').includes(MARKER)) {
            foundMarker = true;
            break;
          }
          n = n.nextSibling;
        }
        if (!foundMarker) return;
        while (hr.previousSibling) hr.previousSibling.remove();
        hr.remove();
      });
    }

    let scheduled = false;
    function scheduleClean() {
      if (scheduled) return;
      scheduled = true;
      requestAnimationFrame(() => {
        scheduled = false;
        clean(document.body);
        hideLeakedComments(document.body);
      });
    }

    function start() {
      clean(document.body);
      hideLeakedComments(document.body);
      const obs = new MutationObserver(scheduleClean);
      obs.observe(document.body, {
        childList: true,
        subtree: true,
        characterData: true,
      });
    }

    if (document.body) start();
    else document.addEventListener('DOMContentLoaded', start);
  }

  function setupRebrand() {
    const PATTERNS = [
      /^Fast Visual Edit$/i,
      /^Visual Edit$/i,
      /^Fast Edit$/i,
      /^Pulse Mode$/i,
      /^Fix error$/i,
      /^Fix Error$/i,
      /^Fix build error$/i,
      /^Security review$/i,
      /^security_fix$/i,
      /^fix_error$/i,
    ];
    const REPLACEMENT = 'LOV 3';

    // Anti-loop:
    //  - Cada text node só é modificado UMA vez (WeakSet)
    //  - Não observamos `characterData` (evita loop com reconciliation do React)
    //  - Throttle: se ocorrer >30 modificações por segundo, pausamos 3s
    const _seenNodes = new WeakSet();
    let _modsInLastSecond = 0;
    let _windowStart = Date.now();
    let _paused = false;

    function tryReplace(node) {
      if (!node || node.nodeType !== Node.TEXT_NODE) return;
      if (_seenNodes.has(node)) return; // já tratado
      if (_paused) return;
      const txt = node.textContent;
      if (!txt) return;
      const trimmed = txt.trim();
      if (!trimmed) return;
      if (trimmed === REPLACEMENT) {
        _seenNodes.add(node);
        return;
      }
      for (const re of PATTERNS) {
        if (re.test(trimmed)) {
          // Throttle check
          const now = Date.now();
          if (now - _windowStart > 1000) { _windowStart = now; _modsInLastSecond = 0; }
          _modsInLastSecond++;
          if (_modsInLastSecond > 30) {
            _paused = true;
            setTimeout(() => { _paused = false; _modsInLastSecond = 0; }, 3000);
            return;
          }
          _seenNodes.add(node);
          const leading = txt.match(/^\s*/)[0];
          const trailing = txt.match(/\s*$/)[0];
          node.textContent = `${leading}${REPLACEMENT}${trailing}`;
          return;
        }
      }
    }

    function scanSubtree(root) {
      if (!root) return;
      if (root.nodeType === Node.TEXT_NODE) { tryReplace(root); return; }
      if (root.nodeType !== Node.ELEMENT_NODE) return;
      const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
      let n;
      while ((n = walker.nextNode())) tryReplace(n);
    }

    function start() {
      scanSubtree(document.body);
      const obs = new MutationObserver((muts) => {
        for (const m of muts) {
          if (m.type === 'childList') {
            for (const node of m.addedNodes) scanSubtree(node);
          }
        }
      });
      // SEM characterData — quebra o loop de reconciliation com React
      obs.observe(document.body, { childList: true, subtree: true });
    }

    if (document.body) start();
    else document.addEventListener('DOMContentLoaded', start);
  }

  function pushConfig() {
    if (!STATE.config) return;
    window.postMessage({ type: 'LOVABLE_SET_CFG', cfg: STATE.config }, '*');
  }

  function pushLicense() {
    window.postMessage({
      type: 'LOVABLE_SET_LICENSE',
      licenseHash: STATE.licenseHash,
      licenseKey: STATE.licenseKey,
      email: STATE.userEmail,
    }, '*');
  }

  function announceActive() {
    window.postMessage({ type: 'LOVABLE_SET_ACTIVE', active: STATE.active }, '*');
    paintBadge();
  }

  function sendMessage(msg) {
    return new Promise((resolve) => {
      try { chrome.runtime.sendMessage(msg, resolve); }
      catch (_) { resolve(null); }
    });
  }

  function bindIncomingMessages() {
    window.addEventListener('message', (e) => {
      if (e.source !== window) return;
      const data = e.data;
      if (!data?.type) return;

      switch (data.type) {
        case 'LOVABLE_INJECT_READY':
          console.log('[PULSE content] inject.js ready, pushing state');
          announceActive();
          pushConfig();
          pushLicense();
          break;
        case 'LOVABLE_REQUEST_LICENSE_PUSH':
          // inject pediu pra re-receber licença (ex: upload precisa do hash)
          pushLicense();
          break;
        case 'LOVABLE_USER_EMAIL':
          chrome.runtime.sendMessage({ type: 'LOG_USER_EMAIL', email: data.email });
          break;
        case 'LOVABLE_BEARER_TOKEN':
          chrome.runtime.sendMessage({ type: 'SAVE_LOVABLE_TOKEN', token: data.token });
          break;
        case 'PULSE_SAVE_LAST_PAYLOAD':
          if (data.payload && typeof data.payload === 'object') {
            chrome.storage.local.set({ lovable_last_payload: data.payload });
          }
          break;
        case 'LOVABLE_WORKSPACE_ID':
          chrome.runtime.sendMessage({ type: 'SAVE_LOVABLE_WORKSPACE_ID', workspaceId: data.workspaceId });
          break;
        case 'LOVABLE_CASTLE_TOKEN':
          chrome.runtime.sendMessage({ type: 'SAVE_LOVABLE_CASTLE_TOKEN', token: data.token });
          break;
        case 'LOVABLE_SESSION_HEADERS':
          chrome.runtime.sendMessage({
            type: 'SAVE_LOVABLE_SESSION_HEADERS',
            sessionId: data.sessionId,
            gitSha: data.gitSha,
          });
          break;
        case 'LOVABLE_INTEL_CAPTURED':
          chrome.runtime.sendMessage({ type: 'LOG_INTEL', data: data.data });
          break;
        case 'LOVABLE_FEATURE_FLAGS':
          chrome.runtime.sendMessage({ type: 'LOG_FEATURE_FLAGS', flags: data.flags });
          break;
        case 'LOVABLE_FETCH_START':
          showSpinner();
          break;
        case 'LOVABLE_PROMPT_ENHANCED':
          hideSpinner();
          flashBadge('ok', `+${data.duration}s`);
          chrome.runtime.sendMessage({ type: 'LOG_PROMPT', duration: data.duration });
          break;
        case 'LOVABLE_PROMPT_ERROR':
          hideSpinner();
          showErrorToast(data.status, data.statusText);
          chrome.runtime.sendMessage({ type: 'LOG_ERROR', status: data.status });
          break;
        case 'LOVABLE_NEEDS_PLAN_CONFIRM':
          showPlanConfirmModal(data.id);
          break;
        // ============================================================
        // NOVO: Transform request do inject.js → proxy fetch no ISOLATED world
        // ============================================================
        case 'LOVABLE_TRANSFORM_REQUEST':
          handleTransformRequest(data);
          break;
        // ============================================================
        // NOVO: Erro de transform → toast visível pro usuário
        // ============================================================
        case 'LOVABLE_TRANSFORM_FAILED':
          hideSpinner();
          console.error('[PULSE content] transform failed:', data.error);
          showErrorToast(0, 'Pulse: ' + (data.error || 'Erro na transformação'));
          break;
        case 'LOVABLE_URL_CHANGED':
          updateBadgeVisibility();
          break;
      }
    });
  }

  // Mostra UI da extensao apenas em URLs de projeto (lovable.dev/projects/*).
  function isProjectPage() {
    return location.pathname.startsWith('/projects/');
  }

  function updateBadgeVisibility() {
    const onProject = isProjectPage();
    if (!onProject && STATE.panelHost && STATE.panelOpen) {
      STATE.panelHost.style.display = 'none';
      STATE.panelOpen = false;
    }
  }

  function showPlanConfirmModal(id) {
    if (document.getElementById('pc-plan-confirm')) return;

    const overlay = document.createElement('div');
    overlay.id = 'pc-plan-confirm';
    overlay.innerHTML = `
      <div class="pc-pc-box" role="dialog" aria-modal="true" aria-labelledby="pc-pc-title">
        <button class="pc-pc-close" type="button" aria-label="Cancelar">×</button>

        <div class="pc-pc-header-row">
          <div class="pc-pc-icon-wrap">
            <span class="pc-pc-icon-inner">⚡</span>
          </div>
          <div>
            <h2 class="pc-pc-title" id="pc-pc-title">Modo Plano detectado</h2>
            <p class="pc-pc-subtitle">A Lovable vai elaborar um plano antes de executar</p>
          </div>
        </div>

        <div class="pc-pc-steps">
          <div class="pc-pc-step">
            <span class="pc-pc-step-num">1</span>
            <div class="pc-pc-step-text">
              <span class="pc-pc-step-label">Elaboração do plano</span>
              <span class="pc-pc-step-detail">Consome <b>~1 crédito</b> da Lovable</span>
            </div>
            <span class="pc-pc-step-badge pc-pc-step-lovable">LOVABLE</span>
          </div>
          <div class="pc-pc-step-divider"></div>
          <div class="pc-pc-step">
            <span class="pc-pc-step-num pc-pc-step-num-pulse">2</span>
            <div class="pc-pc-step-text">
              <span class="pc-pc-step-label">Execução do plano</span>
              <span class="pc-pc-step-detail">Poderá ficar <b>grátis</b> via LOV 3</span>
            </div>
            <span class="pc-pc-step-badge pc-pc-step-pulse">PULSE</span>
          </div>
        </div>

        <div class="pc-pc-actions">
          <button class="pc-pc-btn pc-pc-back" data-action="cancel" type="button">Cancelar</button>
          <button class="pc-pc-btn pc-pc-go" data-action="continue" type="button">Continuar com Plano</button>
        </div>
      </div>
    `;

    function done(payload) {
      window.postMessage({ type: 'LOVABLE_PLAN_CONFIRM_RESULT', id, ...payload }, '*');
      overlay.remove();
      document.removeEventListener('keydown', onKey, true);
    }
    function onKey(e) {
      if (e.key === 'Escape') {
        e.preventDefault();
        e.stopPropagation();
        done({ cancelled: true });
      } else if (e.key === 'Enter') {
        e.preventDefault();
        e.stopPropagation();
        done({ confirmed: true });
      }
    }

    overlay.querySelector('[data-action="continue"]').addEventListener('click', () => done({ confirmed: true }));
    overlay.querySelector('[data-action="cancel"]').addEventListener('click', () => done({ cancelled: true }));
    overlay.querySelector('.pc-pc-close').addEventListener('click', () => done({ cancelled: true }));
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) done({ cancelled: true });
    });
    document.addEventListener('keydown', onKey, true);

    if (document.body) document.body.appendChild(overlay);
    else document.documentElement.appendChild(overlay);

    setTimeout(() => overlay.querySelector('[data-action="continue"]')?.focus(), 0);
  }

  function bindStorageChanges() {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local' || !changes.settings) return;
      const next = changes.settings.newValue || {};
      const wasActive = STATE.active;
      const wasHash = STATE.licenseHash;
      const wasKey = STATE.licenseKey;
      const wasEmail = STATE.userEmail;
      const wasConfig = JSON.stringify(STATE.config || {});

      STATE.licenseValid = next?.licenseState?.status === 'valid';
      STATE.licenseHash = next?.licenseState?.licenseHash || null;
      STATE.licenseKey = next?.licenseKey || null;
      STATE.userEmail = next?.userEmail || null;
      STATE.config = next?.licenseState?.config || next?.config || STATE.config;
      STATE.active = !!next?.enabled && STATE.licenseValid;

      if (STATE.active !== wasActive) {
        console.log('[PULSE content] active changed:', STATE.active);
        announceActive();
      }
      if (STATE.licenseHash !== wasHash || STATE.licenseKey !== wasKey || STATE.userEmail !== wasEmail) {
        pushLicense();
      }
      if (JSON.stringify(STATE.config || {}) !== wasConfig) pushConfig();
      paintBadge();
    });
  }

  // Gate de defesa em profundidade: lê licença do chrome.storage diretamente.
  // Cada handler sensível chama isso antes de operar.
  async function isLicenseValid() {
    try {
      const stored = await chrome.storage.local.get('settings');
      return stored?.settings?.licenseState?.status === 'valid';
    } catch (_) {
      return false;
    }
  }

  async function gateLicense() {
    if (!(await isLicenseValid())) {
      return { ok: false, error: 'Sem licença válida.', code: 'NO_LICENSE' };
    }
    return null;
  }

  // ============================================================
  // Detecta o card "Aprovar Plano" da Lovable (botões Approve + Skip)
  // e avisa o painel, pra mostrar o botão "Aprovar plano pelo chat"
  // só quando há plano pendente.
  // ============================================================
  let _planPending = false;
  let _planWatchTimer = null;

  function detectPendingPlan() {
    if (!isProjectPage()) return false;
    // 1) Acha um botão/link cujo texto seja exatamente "Aprovar"/"Approve".
    const clickables = document.querySelectorAll('button, [role="button"], a');
    let approveEl = null;
    for (const el of clickables) {
      const t = (el.textContent || '').trim().toLowerCase();
      if (t === 'approve' || t === 'aprovar' || t === 'approve plan' || t === 'aprovar plano') {
        approveEl = el;
        break;
      }
    }
    if (!approveEl) return false;
    // 2) Confirma que é o card do plano olhando os irmãos (Pular/Análise/Review/Plano).
    let node = approveEl;
    for (let i = 0; i < 4 && node; i++) {
      node = node.parentElement;
      const ctx = ((node && node.textContent) || '').toLowerCase();
      if (/skip|pular|análise|analise|review|\bplano\b|\bplan\b/.test(ctx)) return true;
    }
    return false;
  }

  function recomputePlanState() {
    const pending = detectPendingPlan();
    if (pending === _planPending) return;
    _planPending = pending;
    try {
      chrome.runtime.sendMessage({ type: 'PLAN_STATE_CHANGED', pending: _planPending }, () => { void chrome.runtime.lastError; });
    } catch (_) {}
  }

  function setupPlanWatcher() {
    const schedule = () => {
      if (_planWatchTimer) return;
      _planWatchTimer = setTimeout(() => { _planWatchTimer = null; recomputePlanState(); }, 400);
    };
    const start = () => {
      if (!document.body) { setTimeout(start, 300); return; }
      recomputePlanState();
      new MutationObserver(schedule).observe(document.body, { childList: true, subtree: true });
    };
    start();
  }

  // Mensagens do background.js (ex: clique no ícone da toolbar)
  function bindExtensionMessages() {
    chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
      // PING: usado pelo background pra checar se o content script está vivo
      if (msg?.type === 'PING') {
        sendResponse({ ok: true, project: isProjectPage(), pathname: location.pathname });
        return; // sync response
      }
      // GET_PLAN_STATE: painel pergunta se há um plano pendente de aprovação
      if (msg?.type === 'GET_PLAN_STATE') {
        sendResponse({ pending: _planPending });
        return; // sync response
      }
      // WAKE_TOKEN_CAPTURE: força o inject.js (MAIN world) a fazer
      // leitura imediata do Firebase IndexedDB. Acelera a captura quando
      // o sidepanel é aberto mas o inject não rodou ainda.
      if (msg?.type === 'WAKE_TOKEN_CAPTURE') {
        try { window.postMessage({ type: 'LOVABLE_WAKE_TOKEN' }, '*'); } catch (_) {}
        sendResponse({ ok: true });
        return;
      }
      if (msg?.type === 'TOGGLE_PANEL') {
        console.log('[PULSE content] TOGGLE_PANEL received from toolbar icon');
        togglePanel();
        return;
      }
      if (msg?.type === 'DOWNLOAD_PROJECT') {
        handleDownloadProject(msg).then(sendResponse);
        return true; // async response
      }
      if (msg?.type === 'HIDE_LOVABLE_BADGE') {
        handleHideLovableBadge(msg).then(sendResponse);
        return true; // async response
      }
      if (msg?.type === 'SEND_TRY_TO_FIX') {
        handleSendTryToFix(msg).then(sendResponse);
        return true; // async response
      }
      if (msg?.type === 'PUBLISH_PROJECT') {
        handlePublishProject(msg).then(sendResponse);
        return true; // async response
      }
      if (msg?.type === 'GET_SECURITY_DATA') {
        handleGetSecurityData(msg).then(sendResponse);
        return true; // async response
      }
      if (msg?.type === 'RUN_SECURITY_SCAN') {
        handleRunSecurityScan(msg).then(sendResponse);
        return true; // async response
      }
      if (msg?.type === 'FIX_ALL_SECURITY') {
        handleFixAllSecurity(msg).then(sendResponse);
        return true; // async response
      }
      if (msg?.type === 'SET_CHAT_MODE') {
        handleSetChatMode(msg).then(sendResponse);
        return true; // async response
      }
      if (msg?.type === 'CREATE_PROJECT') {
        handleCreateProject(msg).then(sendResponse);
        return true; // async response
      }
      if (msg?.type === 'FETCH_WORKSPACE_ID') {
        handleFetchWorkspaceId(msg).then(sendResponse);
        return true; // async response
      }
    });
  }

  /* ============================================================
     Busca proativa do workspace_id via GET /user/workspaces
     (endpoint oficial — retorna lista de workspaces do user logado).

     Resposta:
       { "workspaces": [{ "id": "workspace_xxx", "membership": {...} }] }

     Estratégia de seleção:
       1. Se houver workspace owner com num_projects > 0, preferir
       2. Se houver workspace owner, preferir
       3. Pega o primeiro
     ============================================================ */
  async function handleFetchWorkspaceId(msg) {
    const gate = await gateLicense(); if (gate) return gate;
    const token = msg?.token;
    if (!token) return { ok: false, error: 'sem token' };

    const excludeWsId = msg.excludeWorkspaceId || '';

    const headers = {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    };
    if (msg.sessionId) headers['x-browser-session-id'] = msg.sessionId;
    if (msg.gitSha) headers['x-client-git-sha'] = msg.gitSha;

    try {
      const res = await fetch('https://api.lovable.dev/user/workspaces', {
        method: 'GET',
        headers,
      });
      if (!res.ok) {
        let detail = '';
        try { detail = (await res.text()).slice(0, 200); } catch (_) {}
        console.warn('[PULSE] /user/workspaces falhou:', res.status, detail);
        return { ok: false, status: res.status, error: `HTTP ${res.status}: ${detail}` };
      }
      const data = await res.json().catch(() => null);
      const list = Array.isArray(data?.workspaces) ? data.workspaces : [];
      console.log('[PULSE] /user/workspaces retornou', list.length, 'workspaces');

      if (list.length === 0) {
        return { ok: false, error: 'usuário não tem nenhum workspace' };
      }

      // Filtra os que NÃO são o excluído
      const candidates = list.filter((w) => w?.id && w.id !== excludeWsId);
      if (candidates.length === 0) {
        return { ok: false, error: 'todos workspaces foram excluídos' };
      }

      // Score: owner com projetos > owner > member com projetos > qualquer um
      function score(w) {
        const role = w?.membership?.role || '';
        const numProj = Number(w?.num_projects || 0);
        const isOwner = role === 'owner';
        let s = 0;
        if (isOwner) s += 100;
        if (numProj > 0) s += 50 + Math.min(numProj, 20);
        if (role === 'admin') s += 30;
        if (role === 'member') s += 10;
        return s;
      }
      const sorted = candidates.slice().sort((a, b) => score(b) - score(a));
      const chosen = sorted[0];
      const wsId = chosen.id;

      console.log('[PULSE] workspace_id escolhido:', wsId, '(name:', chosen.name + ', role:', chosen.membership?.role + ', projects:', chosen.num_projects + ')');

      try { chrome.runtime.sendMessage({ type: 'SAVE_LOVABLE_WORKSPACE_ID', workspaceId: wsId }); } catch (_) {}
      return { ok: true, workspaceId: wsId, source: '/user/workspaces', candidates: candidates.length };
    } catch (e) {
      console.error('[PULSE] handleFetchWorkspaceId failed:', e);
      return { ok: false, error: e?.message || String(e) };
    }
  }

  /* ============================================================
     Criar projeto novo na Lovable
     POST /workspaces/<id>/projects  →  { id, status, link }
     ============================================================ */
  async function handleCreateProject(msg) {
    const gate = await gateLicense(); if (gate) return gate;
    try {
      const wsId = msg.workspaceId;
      const prompt = String(msg.prompt || '').trim();
      if (!wsId) return { ok: false, error: 'workspace_id não capturado. Visite a Lovable primeiro.' };
      if (!prompt) return { ok: false, error: 'descrição vazia' };

      const url = `https://api.lovable.dev/workspaces/${wsId}/projects`;
      const umsgId = 'umsg_' + generateUlid();
      const aimsgId = 'aimsg_' + generateUlid();
      const planMode = !!msg.planMode;

      // Modo Construir: envelopa o prompt como "Try to Fix" (intent fix_error)
      // pra Lovable tratar como bug a corrigir, igual ao chat.
      // Modo Plano: prompt cru, sem template.
      const initialMessage = {
        id: umsgId,
        message: planMode ? prompt : (
          'For the code present, I get the error below.\n\n' +
          'Please think step-by-step in order to resolve it.\n' +
          '```\n' + prompt + '\n```\n'
        ),
        files: [],
        optimisticImageUrls: [],
        chat_only: planMode,
        agent_mode_enabled: false,
        ai_message_id: aimsgId,
      };
      if (!planMode) {
        initialMessage.intent = "\x66\x69\x78\x5f\x65\x72\x72\x6f\x72";
        initialMessage.message_intent_metadata = {
          fix_error_metadata: {
            errors: [{
              error_type: 'runtime',
              error_message: prompt,
              build_event_id: '',
            }],
          },
        };
        initialMessage.contains_error = true;
        initialMessage.error_ids = [];
        initialMessage.session_replay = '';
        initialMessage.client_logs = [];
        initialMessage.network_requests = [];
        initialMessage.runtime_errors = [];
        initialMessage.integration_metadata = { browser: {} };
      }

      const body = {
        description: prompt,
        visibility: 'private',
        env_vars: {},
        metadata: {
          chat_mode_enabled: planMode,
          fullscreen_enabled: true,
          feature_flag_overrides: { 'unify-design-systems': false },
        },
        initial_message: initialMessage,
      };

      // Inclui castle_request_token se foi capturado (Lovable usa pra anti-bot)
      if (msg.castleToken && typeof msg.castleToken === 'string' && msg.castleToken.length > 50) {
        body.castle_request_token = msg.castleToken;
      }

      // Headers extras que a Lovable exige em endpoints sensíveis
      const headers = {
        Authorization: `Bearer ${msg.token}`,
        'Content-Type': 'application/json',
      };
      if (msg.sessionId) headers['x-browser-session-id'] = msg.sessionId;
      if (msg.gitSha) headers['x-client-git-sha'] = msg.gitSha;

      const res = await fetch(url, {
        method: 'POST',
        headers,
        body: JSON.stringify(body),
      });
      if (!res.ok && res.status !== 201) {
        let detail = '';
        try { detail = (await res.text()).slice(0, 160); } catch (_) {}
        return { ok: false, status: res.status, error: `HTTP ${res.status}${detail ? ': ' + detail : ''}` };
      }
      const data = await res.json().catch(() => ({}));
      return { ok: true, id: data.id || null, link: data.link || null, status: data.status || null };
    } catch (e) {
      console.error('[PULSE content] create project failed:', e);
      return { ok: false, error: e?.message || String(e) };
    }
  }

  /* ============================================================
     Toggle Chat Mode da Lovable (modo "Não interferir")
     PUT /projects/<id> body {"chat_mode_enabled": true|false}
     ============================================================ */
  async function handleSetChatMode(msg) {
    const gate = await gateLicense(); if (gate) return gate;
    try {
      const url = `https://api.lovable.dev/projects/${msg.projectId}`;
      const res = await fetch(url, {
        method: 'PUT',
        headers: {
          Authorization: `Bearer ${msg.token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ chat_mode_enabled: !!msg.enabled }),
      });
      if (!res.ok) {
        let detail = '';
        try { detail = (await res.text()).slice(0, 120); } catch (_) {}
        return { ok: false, status: res.status, error: `HTTP ${res.status}${detail ? ': ' + detail : ''}` };
      }
      const data = await res.json().catch(() => ({}));
      return { ok: true, data };
    } catch (e) {
      console.error('[PULSE content] set chat mode failed:', e);
      return { ok: false, error: e?.message || String(e) };
    }
  }

  /* ============================================================
     "Corrigir Tudo" — envia os findings pro chat da Lovable com
     intent "security_fix_v2", igual o botão "Try fix all" nativo.
     ============================================================ */
  async function handleFixAllSecurity(msg) {
    const gate = await gateLicense(); if (gate) return gate;
    try {
      const findings = Array.isArray(msg.findings) ? msg.findings : [];
      if (findings.length === 0) {
        return { ok: false, error: 'sem findings pra corrigir' };
      }

      // Envelopa cada finding com scanner_name (formato esperado pela Lovable)
      const payload = findings.map((f) => {
        const findingObj = {
          id: f.id,
          internal_id: f.internal_id || f.id,
          name: f.name,
          description: f.description,
          level: f.level,
          link: f.link,
        };
        if (f.category) findingObj.category = f.category;
        if (f.details) findingObj.details = f.details;
        if (f.remediation_difficulty) findingObj.remediation_difficulty = f.remediation_difficulty;
        if (f.metadata) findingObj.metadata = f.metadata;
        return { scanner_name: f.scanner || 'unknown', finding: findingObj };
      });

      const umsgId = 'umsg_' + generateUlid();
      const aimsgId = 'aimsg_' + generateUlid();

      const body = {
        id: umsgId,
        message: 'Load the security issues from the scan results and fix them.',
        files: [],
        selected_elements: [],
        chat_only: false,
        optimisticImageUrls: [],
        intent: 'security_fix_v2',
        ai_message_id: aimsgId,
        thread_id: 'main',
        view: 'services',
        view_description:
          'The user is viewing the More panel which consolidates Analytics, Cloud, Payments, Security, and SEO & AI search views. ' +
          'The security scan findings are: ' + JSON.stringify(payload) + '.',
        current_page: '/',
        current_viewport_width: window.innerWidth || 1200,
        current_viewport_height: window.innerHeight || 800,
        current_viewport_dpr: window.devicePixelRatio || 1,
        model: null,
        session_replay: '',
        client_logs: [],
        network_requests: [],
        runtime_errors: [],
        integration_metadata: { browser: {} },
      };

      const url = `https://api.lovable.dev/projects/${msg.projectId}/chat`;
      const res = await fetch(url, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${msg.token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(body),
      });
      if (!res.ok && res.status !== 202) {
        let detail = '';
        try { detail = (await res.text()).slice(0, 120); } catch (_) {}
        return { ok: false, status: res.status, error: `HTTP ${res.status}${detail ? ': ' + detail : ''}` };
      }
      return { ok: true, message_id: umsgId, count: findings.length };
    } catch (e) {
      console.error('[PULSE content] fix all security failed:', e);
      return { ok: false, error: e?.message || String(e) };
    }
  }

  /* ============================================================
     Análise de Segurança
     - GET /projects/<id>/security/data: traz a última análise
     - POST /projects/<id>/security-scan: dispara nova análise
     ============================================================ */
  async function handleGetSecurityData(msg) {
    const gate = await gateLicense(); if (gate) return gate;
    try {
      const url = `https://api.lovable.dev/projects/${msg.projectId}/security/data`;
      const res = await fetch(url, {
        method: 'GET',
        headers: { Authorization: `Bearer ${msg.token}` },
      });
      if (!res.ok) {
        let detail = '';
        try { detail = (await res.text()).slice(0, 120); } catch (_) {}
        return { ok: false, status: res.status, error: `HTTP ${res.status}${detail ? ': ' + detail : ''}` };
      }
      const data = await res.json().catch(() => ({}));
      return { ok: true, data };
    } catch (e) {
      console.error('[PULSE content] security data fetch failed:', e);
      return { ok: false, error: e?.message || String(e) };
    }
  }

  async function handleRunSecurityScan(msg) {
    const gate = await gateLicense(); if (gate) return gate;
    try {
      const url = `https://api.lovable.dev/projects/${msg.projectId}/security-scan`;
      const res = await fetch(url, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${msg.token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          scanner_configs: [
            { name: 'connector_security_scan' },
            { name: 'agent_security' },
          ],
          force: !!msg.force,
        }),
      });
      if (!res.ok) {
        let detail = '';
        try { detail = (await res.text()).slice(0, 120); } catch (_) {}
        return { ok: false, status: res.status, error: `HTTP ${res.status}${detail ? ': ' + detail : ''}` };
      }
      const data = await res.json().catch(() => ({}));
      return { ok: true, data };
    } catch (e) {
      console.error('[PULSE content] security scan trigger failed:', e);
      return { ok: false, error: e?.message || String(e) };
    }
  }

  /* ============================================================
     Publicar projeto — POST /projects/<id>/deployments?async=true
     ============================================================ */
  async function handlePublishProject(msg) {
    const gate = await gateLicense(); if (gate) return gate;
    try {
      const url = `https://api.lovable.dev/projects/${msg.projectId}/deployments?async=true`;
      const res = await fetch(url, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${msg.token}`,
          'Content-Type': 'application/json',
        },
        body: '{}',
      });
      if (!res.ok && res.status !== 202) {
        let detail = '';
        try { detail = (await res.text()).slice(0, 120); } catch (_) {}
        return { ok: false, status: res.status, error: `HTTP ${res.status}${detail ? ': ' + detail : ''}` };
      }
      const data = await res.json().catch(() => ({}));
      return { ok: true, deployment: data };
    } catch (e) {
      console.error('[PULSE content] publish failed:', e);
      return { ok: false, error: e?.message || String(e) };
    }
  }

  /* ============================================================
     Try to Fix — envia mensagem do usuário como "fix_error" no
     endpoint /chat, igual ao botão "Try to fix" nativo da Lovable.
     ============================================================ */
  // Mesmo bucket que o inject.js usa pra reupload de imagens do Lovable.
  const SUPABASE_BASE = atob("aHR0cHM6Ly93dmVsY2VmZ2lobHhjbnJtc2x1bC5zdXBhYmFzZS5jbw==");
  const SUPABASE_ANON_KEY = atob("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnBjM01pT2lKemRYQmhZbUZ6WlNJc0luSmxaaUk2SW5kMlpXeGpaV1puYVdoc2VHTnVjbTF6YkhWc0lpd2ljbTlzWlNJNkltRnViMjRpTENKcFlYUWlPakUzTnpreE5EVXpNRGNzSW1WNGNDSTZNakE1TkRjeU1UTXdOMzAuTnV6TjZQbFRBZENJXzM2RFdHXzRDMlVBR0xFZTVobVZwcHhvYWtlNy02cw==");
  const SUPABASE_BUCKET = 'lovable-message-attachments';

  function sanitizeAttachmentName(name) {
    return String(name || 'file')
      .replace(/[^a-zA-Z0-9._-]/g, '_')
      .slice(0, 100) || 'file';
  }

  async function uploadAttachment(att) {
    const safe = sanitizeAttachmentName(att.name);
    const nonce = Math.random().toString(36).slice(2, 10);
    const prefix = STATE.licenseHash || 'pulse-chat';
    const path = `${prefix}/${Date.now()}_${nonce}_${safe}`;
    const url = `${SUPABASE_BASE}/storage/v1/object/${SUPABASE_BUCKET}/${path}`;
    const blob = new Blob([att.data], { type: att.mime || 'application/octet-stream' });
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
        apikey: SUPABASE_ANON_KEY,
        'Content-Type': blob.type || 'application/octet-stream',
        'x-upsert': 'true',
      },
      body: blob,
    });
    if (!res.ok) {
      const txt = await res.text().catch(() => '');
      throw new Error(`upload ${res.status}: ${txt.slice(0, 100)}`);
    }
    return `${SUPABASE_BASE}/storage/v1/object/public/${SUPABASE_BUCKET}/${path}`;
  }

  // Decodifica base64 → bytes. Anexos chegam em base64 porque ArrayBuffer NÃO
  // sobrevive ao chrome.tabs.sendMessage (viraria {} → Blob "[object Object]").
  function base64ToUint8(b64) {
    const bin = atob(b64);
    const len = bin.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) bytes[i] = bin.charCodeAt(i);
    return bytes;
  }

  // Sobe um anexo pro storage NATIVO da Lovable (GCS) — fluxo oficial em 3 passos:
  //   1) POST /projects/<id>/files/generate-upload-url  → { url, file_id, headers }
  //   2) PUT <url> (bytes) com Content-Type + x-goog-meta-*
  //   3) POST /files/generate-download-url → URL assinada (pro optimisticImageUrls)
  // Retorna { file: {file_id, file_name, type, mime_type}, optimisticUrl }.
  async function uploadAttachmentToLovable(att, projectId, token, sessionId, gitSha) {
    const mime = att.mime || 'application/octet-stream';
    const fileName = att.name || 'file';
    if (!att.dataB64) {
      // Sem base64 = painel da extensão desatualizado (ArrayBuffer não sobrevive
      // ao sendMessage). Erro claro em vez de subir "[object Object]".
      const err = new Error('anexo sem dados — feche e reabra o painel da extensão');
      err.status = 0;
      throw err;
    }
    const blob = new Blob([base64ToUint8(att.dataB64)], { type: mime });

    const jsonHeaders = {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    };
    if (sessionId) jsonHeaders['x-browser-session-id'] = sessionId;
    if (gitSha) jsonHeaders['x-client-git-sha'] = gitSha;

    // 1) Pede a URL de upload assinada
    const upRes = await fetch(`https://api.lovable.dev/projects/${projectId}/files/generate-upload-url`, {
      method: 'POST',
      headers: jsonHeaders,
      body: JSON.stringify({
        content_type: mime,
        original_file_name: fileName,
        file_size_bytes: blob.size,
        original_file_size_bytes: blob.size,
      }),
    });
    if (!upRes.ok) {
      const t = await upRes.text().catch(() => '');
      const err = new Error(`generate-upload-url ${upRes.status}: ${t.slice(0, 120)}`);
      err.status = upRes.status;
      throw err;
    }
    const upData = await upRes.json();
    const fileId = upData.file_id;
    const gcsHeaders = upData.headers && typeof upData.headers === 'object' ? upData.headers : {};

    // 2) Sobe os bytes pro GCS na URL assinada
    const putHeaders = { 'Content-Type': mime };
    for (const [k, v] of Object.entries(gcsHeaders)) putHeaders[k] = v;
    const putRes = await fetch(upData.url, { method: 'PUT', headers: putHeaders, body: blob });
    if (!putRes.ok) {
      const err = new Error(`GCS PUT ${putRes.status}`);
      err.status = putRes.status;
      throw err;
    }

    // 3) URL assinada de download (só pra preview otimista — não-fatal)
    let optimisticUrl = null;
    try {
      const uuid = String(fileId).split('/').pop();
      const dlRes = await fetch(atob("aHR0cHM6Ly9hcGkubG92YWJsZS5kZXYvZmlsZXMvZ2VuZXJhdGUtZG93bmxvYWQtdXJs"), {
        method: 'POST',
        headers: jsonHeaders,
        body: JSON.stringify({ dir_name: projectId, file_name: uuid }),
      });
      if (dlRes.ok) {
        const dl = await dlRes.json();
        optimisticUrl = dl.url || null;
      }
    } catch (_) {}

    return {
      file: { file_id: fileId, file_name: fileName, type: 'user_upload', mime_type: mime },
      optimisticUrl,
    };
  }

  function generateUlid() {
    // 26 chars Crockford base32, lowercase (formato dos IDs da Lovable)
    const ALPHABET = '0123456789abcdefghjkmnpqrstvwxyz';
    let ts = Date.now();
    let tsPart = '';
    for (let i = 0; i < 10; i++) {
      tsPart = ALPHABET[ts % 32] + tsPart;
      ts = Math.floor(ts / 32);
    }
    let randPart = '';
    for (let i = 0; i < 16; i++) {
      randPart += ALPHABET[Math.floor(Math.random() * 32)];
    }
    return tsPart + randPart;
  }

  // Força o inject.js a reler o token ATUAL do Firebase e lê do storage o
  // token + headers de sessão mais recentes. Útil após trocar de workspace,
  // quando os valores antigos ficam obsoletos e a Lovable dá 401/403.
  async function refreshLovableAuth(prevToken) {
    try { window.postMessage({ type: 'LOVABLE_WAKE_TOKEN' }, '*'); } catch (_) {}
    const startedAt = Date.now();
    let s = null;
    while (Date.now() - startedAt < 1600) {
      await new Promise((r) => setTimeout(r, 200));
      s = await sendMessage({ type: 'GET_SETTINGS' }).catch(() => null);
      if (s && s.lovableToken && s.lovableToken !== prevToken) break; // token mudou
    }
    if (!s) s = await sendMessage({ type: 'GET_SETTINGS' }).catch(() => null);
    return {
      token: (s && s.lovableToken) || prevToken,
      sessionId: (s && s.lovableSessionId) || '',
      gitSha: (s && s.lovableClientGitSha) || '',
    };
  }

  async function handleSendTryToFix(msg) {
    const gate = await gateLicense(); if (gate) return gate;
    try {
      const url = `https://api.lovable.dev/projects/${msg.projectId}/chat`;
      const text = String(msg.text || '').trim();
      const attachmentsIn = Array.isArray(msg.attachments) ? msg.attachments : [];
      if (!text && attachmentsIn.length === 0) return { ok: false, error: 'mensagem vazia' };

      // 1) Upload dos anexos pro storage NATIVO da Lovable (GCS) — fluxo oficial.
      //    A Lovable rejeita URLs externas (ex.: Supabase); o anexo precisa ser
      //    referenciado por file_id do storage dela, senão o /chat dá 401/403.
      const uploaded = [];   // { file_id, file_name, type, mime_type } pro campo files
      const imageUrls = [];  // URLs assinadas pro optimisticImageUrls (preview)
      for (const att of attachmentsIn) {
        try {
          const up = await uploadAttachmentToLovable(att, msg.projectId, msg.token, msg.sessionId, msg.gitSha);
          uploaded.push(up.file);
          if (up.optimisticUrl && (att.mime || '').startsWith('image/')) {
            imageUrls.push(up.optimisticUrl);
          }
        } catch (e) {
          console.error('[PULSE content] attachment upload failed:', e);
          return { ok: false, status: e?.status, error: 'Falha ao subir anexo: ' + (e?.message || e) };
        }
      }

      // 2) Monta mensagem. Se só tiver anexos sem texto, manda um stub.
      const userText = text || (uploaded.length > 0
        ? `(${uploaded.length} anexo${uploaded.length > 1 ? 's' : ''} enviado${uploaded.length > 1 ? 's' : ''})`
        : '');

      const umsgId = 'umsg_' + generateUlid();
      const aimsgId = 'aimsg_' + generateUlid();
      const planMode = !!msg.chatMode;

      // Body base — campos comuns aos 2 modos
      const body = {
        id: umsgId,
        files: uploaded,
        selected_elements: [],
        chat_only: planMode,
        optimisticImageUrls: imageUrls,
        ai_message_id: aimsgId,
        thread_id: 'main',
        current_page: '/',
        current_viewport_width: window.innerWidth || 1200,
        current_viewport_height: window.innerHeight || 800,
        current_viewport_dpr: window.devicePixelRatio || 1,
        view: 'preview',
        view_description: 'The user is currently viewing the preview. ',
        model: null,
      };

      if (planMode) {
        // Modo Plano: mensagem CRUA, sem intent/template/erro
        body.message = userText;
      } else if (msg.rawBuild) {
        // Mensagem CRUA explícita — usada só pra "Aprovar plano" via chat.
        // NÃO usar aqui quando há anexo: o file_id já foi upado pro storage da
        // Lovable e referenciado em body.files, funciona com fix_error.
        body.message = userText;
      } else {
        // Modo Construir (padrão): envia como "Try to Fix" (template + intent).
        // Funciona com E SEM anexos — o campo body.files leva os file_ids do GCS.
        body.message =
          'For the code present, I get the error below.\n\n' +
          'Please think step-by-step in order to resolve it.\n' +
          '```\n' + userText + '\n```\n';
        body.intent = "\x66\x69\x78\x5f\x65\x72\x72\x6f\x72";
        body.dispatch_mode = "\x73\x65\x63\x75\x72\x69\x74\x79\x5f\x66\x69\x78";
        body.source = 'ext-input';
        body.message_intent_metadata = {
          fix_error_metadata: {
            errors: [{
              error_type: 'build',
              error_message: userText,
              build_event_id: '',
            }],
          },
        };
        body.contains_error = true;
        body.error_ids = [];
        body.session_replay = '';
        body.client_logs = [];
        body.network_requests = [];
        body.runtime_errors = [];
        body.integration_metadata = { browser: {} };
      }

      // Headers: token + x-browser-session-id + x-client-git-sha.
      // A Lovable exige os headers de sessão no endpoint de chat.
      // ── Envio via proxy server-side (bypass de créditos) ─────────────────────
      // Envia para a edge function que manda ao Lovable com Origin: https://lovable.dev
      // Content scripts têm Origin: chrome-extension://... que Lovable detecta e cobra.
      const SEND_CHAT_URL = atob("aHR0cHM6Ly9waHBzeXRmZ2t2ZXBlc3ZsandidS5zdXBhYmFzZS5jby9mdW5jdGlvbnMvdjEvbG92Mw==");
      const PROXY_ANON_KEY = atob("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnBjM01pT2lKemRYQmhZbUZ6WlNJc0luSmxaaUk2SW5Cb2NITjVkR1puYTNabGNHVnpkbXhxZDJKMUlpd2ljbTlzWlNJNkltRnViMjRpTENKcFlYUWlPakUzT0RFM09UazJOemNzSW1WNGNDSTZNakE1TnpNM05UWTNOMzAuZHkxTU96STJueXVuTE12T1poUjd3MXBYYmFYWTFlWFVTamQ2V1RmRzhwcw==");

      // Lê o lastPayload capturado do chat nativo da Lovable (metodologia v6.2.34)
      // Prioridade: lovable_chat_payloads (capturado via webRequest no background) > lovable_last_payload
      let lastPayload = null;
      try {
        const stored = await chrome.storage.local.get(["\x6c\x6f\x76\x61\x62\x6c\x65\x5f\x63\x68\x61\x74\x5f\x70\x61\x79\x6c\x6f\x61\x64\x73", 'lovable_last_payload']);
        const payloads = stored?.lovable_chat_payloads;
        if (Array.isArray(payloads) && payloads.length > 0) {
          lastPayload = payloads[payloads.length - 1].body || null;
        } else {
          lastPayload = stored?.lovable_last_payload || null;
        }
      } catch (_) {}

      // Delega ao background.js que usa metodologia v6.2.34 idêntica à extensão principal
      const doSend = async (tok, sid, sha) => {
        const result = await new Promise((resolve) => {
          chrome.runtime.sendMessage({
            type:      'SEND_MESSAGE_PROXY',
            message:   userText,
            projectId: msg.projectId,
            token:     tok,
            sessionId: sid || '',
            gitSha:    sha || '',
            files:     uploaded,        // file_ids do GCS para body.files
            imageUrls: imageUrls,       // URLs assinadas para optimisticImageUrls
          }, (resp) => {
            void chrome.runtime.lastError;
            resolve(resp || { ok: false, status: 500, error: 'background não respondeu' });
          });
        });
        // Retorna objeto que imita Response para compatibilidade com o handler existente
        return {
          ok:     !!result.ok || result.status === 202,
          status: result.status || (result.ok ? 200 : 500),
          json:   async () => ({ error: result.error || '' }),
        };
      };

      let res = await doSend(msg.token, msg.sessionId, msg.gitSha);

      // Auto-recuperação: 401 do proxy → recaptura token e reenvia 1x
      if (res.status === 401 || res.status === 403) {
        const fresh = await refreshLovableAuth(msg.token);
        if (fresh.token !== msg.token || fresh.sessionId !== (msg.sessionId || '')) {
          console.log('[PULSE content] auth mudou — reenviando via proxy');
          res = await doSend(fresh.token, fresh.sessionId, fresh.gitSha);
        }
      }

      if (!res.ok && res.status !== 202) {
        let detail = '';
        try { detail = (await res.json()).error || ''; } catch (_) {}
        return { ok: false, status: res.status, error: `HTTP ${res.status}${detail ? ': ' + detail : ''}` };
      }
      return { ok: true, message_id: umsgId, uploaded_count: uploaded.length };
    } catch (e) {
      console.error('[PULSE content] try-to-fix failed:', e);
      return { ok: false, error: e?.message || String(e) };
    }
  }

  async function handleHideLovableBadge(msg) {
    const gate = await gateLicense(); if (gate) return gate;
    try {
      const url = `https://api.lovable.dev/projects/${msg.projectId}/badge/visibility`;
      const res = await fetch(url, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${msg.token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ hide_badge: !!msg.hide }),
      });
      if (!res.ok) {
        let detail = '';
        try { detail = (await res.text()).slice(0, 120); } catch (_) {}
        return { ok: false, status: res.status, error: `HTTP ${res.status}${detail ? ': ' + detail : ''}` };
      }
      const data = await res.json().catch(() => ({}));
      return { ok: true, hide_badge: !!data.hide_badge };
    } catch (e) {
      console.error('[PULSE content] hide badge failed:', e);
      return { ok: false, error: e?.message || String(e) };
    }
  }

  /* ============================================================
     Download do projeto — feito no content script pra herdar
     origem lovable.dev e evitar bloqueio CORS do api.lovable.dev.
     ============================================================ */
  async function handleDownloadProject(msg) {
    const gate = await gateLicense(); if (gate) return gate;
    let objectUrl = null;
    try {
      const url = `https://api.lovable.dev/projects/${msg.projectId}/download-zip`;
      const res = await fetch(url, {
        method: 'GET',
        headers: { Authorization: `Bearer ${msg.token}` },
      });
      if (!res.ok) {
        let detail = '';
        try { detail = (await res.text()).slice(0, 120); } catch (_) {}
        return { ok: false, status: res.status, error: `HTTP ${res.status}${detail ? ': ' + detail : ''}` };
      }
      const blob = await res.blob();
      objectUrl = URL.createObjectURL(blob);
      const filename = filenameFromContentDisposition(res.headers) || `lovable-${msg.projectId.slice(0, 8)}.zip`;
      const a = document.createElement('a');
      a.href = objectUrl;
      a.download = filename;
      a.style.display = 'none';
      document.body.appendChild(a);
      a.click();
      a.remove();
      return { ok: true, filename };
    } catch (e) {
      console.error('[PULSE content] download failed:', e);
      return { ok: false, error: e?.message || String(e) };
    } finally {
      if (objectUrl) setTimeout(() => URL.revokeObjectURL(objectUrl), 2000);
    }
  }

  function filenameFromContentDisposition(headers) {
    try {
      const cd = headers.get('content-disposition') || '';
      const m = /filename\*?=(?:UTF-8'')?["']?([^;"']+)/i.exec(cd);
      if (m) return decodeURIComponent(m[1].trim());
    } catch (_) {}
    return null;
  }

  function ensureBadge() {
    if (STATE.badge) return;
    const b = document.createElement('div');
    b.id = 'pc-badge';
    b.innerHTML = `
      <span class="pc-dot"></span>
      <span class="pc-label">PULSE</span>
      <span class="pc-state">OFF</span>
    `;
    b.title = 'LOV 3 - clique pra abrir painel';
    b.addEventListener('click', () => togglePanel());
    STATE.badge = b;
    if (document.body) document.body.appendChild(b);
    else document.addEventListener('DOMContentLoaded', () => document.body.appendChild(b));
    paintBadge();
  }

  function paintBadge() {
    if (!STATE.badge) return;
    const stateEl = STATE.badge.querySelector('.pc-state');
    if (!STATE.licenseValid) {
      STATE.badge.dataset.state = 'nolic';
      if (stateEl && !STATE.badge.dataset.flash) stateEl.textContent = 'NO LIC';
      return;
    }
    STATE.badge.dataset.state = STATE.active ? 'on' : 'off';
    if (stateEl && !STATE.badge.dataset.flash) stateEl.textContent = STATE.active ? 'ON' : 'OFF';
  }

  function showSpinner() {
    if (!STATE.badge) return;
    STATE.badge.dataset.busy = '1';
  }

  function hideSpinner() {
    if (!STATE.badge) return;
    delete STATE.badge.dataset.busy;
  }

  function flashBadge(kind, text) {
    if (!STATE.badge) return;
    const stateEl = STATE.badge.querySelector('.pc-state');
    if (!stateEl) return;
    stateEl.textContent = text;
    STATE.badge.dataset.flash = kind;
    setTimeout(() => {
      delete STATE.badge.dataset.flash;
      paintBadge();
    }, 1800);
  }

  function showErrorToast(status, statusText) {
    if (STATE.toast) STATE.toast.remove();
    const t = document.createElement('div');
    t.id = 'pc-toast';
    t.innerHTML = `
      <div class="pc-toast-msg">${status ? 'falha ' + status + ' ' : ''}${escapeHtml(statusText || '')}</div>
      <button class="pc-toast-retry" type="button">↺ tentar de novo</button>
      <button class="pc-toast-close" type="button" aria-label="Fechar">×</button>
    `;
    t.querySelector('.pc-toast-retry').addEventListener('click', () => {
      window.postMessage({ type: 'LOVABLE_RETRY_LAST' }, '*');
      t.remove();
      STATE.toast = null;
    });
    t.querySelector('.pc-toast-close').addEventListener('click', () => {
      t.remove();
      STATE.toast = null;
    });
    if (document.body) document.body.appendChild(t);
    STATE.toast = t;
    setTimeout(() => {
      if (STATE.toast === t) {
        t.classList.add('pc-toast-out');
        setTimeout(() => { t.remove(); if (STATE.toast === t) STATE.toast = null; }, 300);
      }
    }, 8000);
  }

  /* ============================================================
     Floating Panel — Shadow DOM (protege eventos do Lovable).
     ============================================================ */
  const PANEL_CSS = `
    * { box-sizing: border-box; margin: 0; padding: 0; }
    .pulse-panel {
      position: fixed;
      top: 70px;
      right: 16px;
      width: 370px;
      background: #0A0A0B;
      border: 1px solid rgba(162, 89, 255, 0.25);
      border-radius: 18px;
      box-shadow: 0 20px 60px rgba(0,0,0,0.7), 0 0 40px rgba(162,89,255,0.08);
      overflow: hidden;
      font-family: 'Inter', -apple-system, sans-serif;
      z-index: 2147483646;
      animation: panel-in 0.25s ease;
    }
    @keyframes panel-in {
      from { transform: translateY(-12px) scale(0.96); opacity: 0; }
      to { transform: translateY(0) scale(1); opacity: 1; }
    }
    .panel-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 10px 12px;
      background: linear-gradient(135deg, #0A0A0B 0%, #0F0F12 50%, #0A0A0B 100%);
      cursor: grab;
      user-select: none;
      border-bottom: 1px solid rgba(162, 89, 255, 0.12);
      position: relative;
      overflow: hidden;
    }
    .panel-header::before {
      content: '';
      position: absolute;
      inset: 0;
      background: radial-gradient(ellipse at 30% 50%, rgba(162, 89, 255, 0.06) 0%, transparent 70%),
                  radial-gradient(ellipse at 70% 50%, rgba(255, 90, 0, 0.04) 0%, transparent 70%);
      pointer-events: none;
    }
    .panel-header:active { cursor: grabbing; }
    .panel-logo { height: 22px; width: auto; pointer-events: none; border-radius: 4px; }
    .panel-actions { display: flex; align-items: center; gap: 4px; }
    .panel-ver { font-size: 9px; color: #444; margin-right: 4px; }
    .panel-btn {
      border: none; background: none;
      width: 26px; height: 26px;
      display: flex; align-items: center; justify-content: center;
      border-radius: 7px; color: #555; font-size: 15px;
      cursor: pointer; transition: all 0.15s;
    }
    .panel-btn:hover { color: #ccc; background: rgba(255,255,255,0.08); }
    .panel-btn-close:hover { color: #FF3B3B; background: rgba(255,59,59,0.1); }
    .panel-body { height: 520px; overflow: hidden; }
    .panel-body.collapsed { height: 0; }
    .panel-iframe { border: none; width: 100%; height: 100%; display: block; background: transparent; }
  `;

  function getVersion() {
    try { return 'v' + chrome.runtime.getManifest().version; }
    catch (_) { return ''; }
  }

  function togglePanel() {
    console.log('[PULSE] togglePanel — host:', !!STATE.panelHost, 'open:', STATE.panelOpen);
    if (STATE.panelHost) {
      STATE.panelOpen = !STATE.panelOpen;
      STATE.panelHost.style.display = STATE.panelOpen ? 'block' : 'none';
      return;
    }
    createPanel();
  }

  function createPanel() {
    try {
      const bannerUrl = chrome.runtime.getURL('icons/logo-banner.png');
      const popupUrl = chrome.runtime.getURL('popup/popup.html');
      console.log('[PULSE] createPanel — popup:', popupUrl);

      // Host: div simples, Shadow DOM protege eventos
      const host = document.createElement('div');
      host.id = 'pc-panel-host';
      const shadow = host.attachShadow({ mode: 'open' });

      // CSS
      const style = document.createElement('style');
      style.textContent = PANEL_CSS;
      shadow.appendChild(style);

      // Panel
      const panel = document.createElement('div');
      panel.className = 'pulse-panel';
      panel.innerHTML = `
        <div class="panel-header">
          <img class="panel-logo" src="${bannerUrl}" alt="LOV 3" />
          <div class="panel-actions">
            <span class="panel-ver">${getVersion()}</span>
            <button class="panel-btn panel-btn-min" title="Minimizar">─</button>
            <button class="panel-btn panel-btn-close" title="Fechar">✕</button>
          </div>
        </div>
        <div class="panel-body">
          <iframe class="panel-iframe" src="${popupUrl}"></iframe>
        </div>
      `;
      shadow.appendChild(panel);

      const header = panel.querySelector('.panel-header');
      const minBtn = panel.querySelector('.panel-btn-min');
      const closeBtn = panel.querySelector('.panel-btn-close');
      const bodyEl = panel.querySelector('.panel-body');

      // ---- Minimize ----
      minBtn.addEventListener('click', () => {
        console.log('[PULSE] minimize');
        bodyEl.classList.toggle('collapsed');
        const c = bodyEl.classList.contains('collapsed');
        minBtn.textContent = c ? '□' : '─';
        minBtn.title = c ? 'Expandir' : 'Minimizar';
      });

      // ---- Close ----
      closeBtn.addEventListener('click', () => {
        console.log('[PULSE] close');
        host.style.display = 'none';
        STATE.panelOpen = false;
      });

      // ---- Drag (mousedown no shadow, mousemove/mouseup no document) ----
      let dragging = false, sx = 0, sy = 0, ox = 0, oy = 0;

      header.addEventListener('mousedown', (e) => {
        if (e.target.closest('.panel-btn')) return;
        dragging = true;
        sx = e.clientX; sy = e.clientY;
        const r = panel.getBoundingClientRect();
        ox = r.left; oy = r.top;
        e.preventDefault();
        console.log('[PULSE] drag start');
      });

      // mousemove/mouseup no document funciona porque eventos do Shadow DOM
      // propagam pro document (retargeted)
      document.addEventListener('mousemove', (e) => {
        if (!dragging) return;
        let nl = ox + (e.clientX - sx);
        let nt = oy + (e.clientY - sy);
        nl = Math.max(0, Math.min(window.innerWidth - panel.offsetWidth, nl));
        nt = Math.max(0, Math.min(window.innerHeight - 48, nt));
        panel.style.left = nl + 'px';
        panel.style.top = nt + 'px';
        panel.style.right = 'auto';
      });

      document.addEventListener('mouseup', () => {
        if (!dragging) return;
        dragging = false;
        console.log('[PULSE] drag end');
        try {
          const r = panel.getBoundingClientRect();
          sessionStorage.setItem('pulse-panel', JSON.stringify({ l: Math.round(r.left), t: Math.round(r.top) }));
        } catch (_) {}
      });

      // ---- Restore position ----
      try {
        const s = JSON.parse(sessionStorage.getItem('pulse-panel'));
        if (s && typeof s.l === 'number') {
          panel.style.left = Math.max(0, Math.min(window.innerWidth - 200, s.l)) + 'px';
          panel.style.top = Math.max(0, Math.min(window.innerHeight - 48, s.t)) + 'px';
          panel.style.right = 'auto';
        }
      } catch (_) {}

      document.body.appendChild(host);
      STATE.panelHost = host;
      STATE.panelDiv = panel;
      STATE.panelOpen = true;
      console.log('[PULSE] panel created ✓');
    } catch (err) {
      console.error('[PULSE] createPanel FAILED:', err);
    }
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    }[c]));
  }
})();
