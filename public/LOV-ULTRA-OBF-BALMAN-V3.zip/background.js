import { getSettings, setSettings } from './lib/storage.js';
import {
  getLicenseState,
  validateLicense,
  clearLicense,
  emptyLicenseState,
} from './lib/license.js';

// ============================================================
// Anti-tampering: garante que estamos rodando no contexto correto
// de uma extensão Chrome (não em copy/repackage por terceiros).
// ============================================================
const _PULSE_RUNTIME_OK = (() => {
  try {
    if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.id) return false;
    const m = chrome.runtime.getManifest?.();
    if (!m) return false;
    // Nome da extensão precisa bater
    if (m.name !== 'Ilimitado Lov') return false;
    // Service worker precisa ser MV3
    if (m.manifest_version !== 3) return false;
    return true;
  } catch (_) {
    return false;
  }
})();

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!_PULSE_RUNTIME_OK) {
    sendResponse({ ok: false, error: 'runtime invalid' });
    return;
  }
  return _PULSE_handler(msg, _sender, sendResponse);
});

function _PULSE_handler(msg, _sender, sendResponse) {
  (async () => {
    try {
      switch (msg.type) {
        case 'GET_SETTINGS':
          // Check local de expiração antes de responder
          await checkLocalExpiry();
          sendResponse(await getSettings());
          break;

        case 'SET_SETTINGS': {
          const updated = await setSettings(msg.updates || {});
          updateBadge(updated);
          sendResponse(updated);
          break;
        }

        case 'TOGGLE_ENABLED': {
          const cur = await getSettings();
          // Desligar sempre permitido
          if (cur.enabled) {
            const updated = await setSettings({ enabled: false });
            updateBadge(updated);
            sendResponse(updated);
            break;
          }
          // Tentando LIGAR — validações em sequência:
          // 1) Licença válida
          const state = await getLicenseState({ force: true });
          if (state.status !== 'valid') {
            const updated = await setSettings({ enabled: false });
            updateBadge(updated);
            sendResponse({ ...updated, error: state.error || 'Sem licença válida' });
            break;
          }
          // 2) Aba ativa precisa ser um projeto Lovable
          const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
          const url = tab?.url || '';
          const isProjectUrl = /https:\/\/lovable\.dev\/projects\/[a-f0-9-]+/i.test(url);
          if (!tab?.id || !isProjectUrl) {
            sendResponse({
              ...cur,
              error: 'Abra um projeto Lovable em lovable.dev/projects/<id> antes de ativar.',
            });
            break;
          }
          // 3) Content script precisa estar vivo (responde a PING)
          let pingOk = false;
          try {
            const pingPromise = chrome.tabs.sendMessage(tab.id, { type: 'PING' });
            const timeoutPromise = new Promise((_, reject) =>
              setTimeout(() => reject(new Error('ping-timeout')), 1500)
            );
            const pong = await Promise.race([pingPromise, timeoutPromise]);
            pingOk = !!pong?.ok;
          } catch (_) {
            pingOk = false;
          }
          if (!pingOk) {
            sendResponse({
              ...cur,
              error: 'Recarregue a aba do Lovable (F5) e tente novamente.',
            });
            break;
          }
          // Tudo OK — liga
          const updated = await setSettings({ enabled: true });
          updateBadge(updated);
          sendResponse(updated);
          break;
        }

        case 'VALIDATE_LICENSE': {
          // Aceita key opcional pra ativar uma nova; se não vier, revalida a atual.
          const cur = await getSettings();
          const key = msg.key !== undefined ? msg.key : cur.licenseKey;
          const email = msg.email !== undefined ? msg.email : cur.userEmail;
          if (msg.key !== undefined && msg.key !== cur.licenseKey) {
            await setSettings({ licenseKey: key, licenseState: emptyLicenseState() });
          }
          const state = await validateLicense(key, email);
          if (state.status !== 'valid') {
            const updated = await setSettings({ enabled: false });
            updateBadge(updated);
          }
          sendResponse(state);
          break;
        }

        case 'GET_LICENSE_STATE': {
          const state = await getLicenseState({ force: !!msg.force });
          sendResponse(state);
          break;
        }

        case 'CLEAR_LICENSE': {
          await clearLicense();
          const updated = await setSettings({ enabled: false });
          updateBadge(updated);
          sendResponse(updated);
          break;
        }

        case 'LOG_USER_EMAIL': {
          const cur = await getSettings();
          const incoming = msg.email || '';
          if (incoming && incoming !== cur.userEmail) {
            await setSettings({ userEmail: incoming });
            // Se já tem licença, força revalidação pra fazer bind do email.
            if (cur.licenseKey) {
              validateLicense(cur.licenseKey, incoming).catch(() => {});
            }
          }
          sendResponse({ ok: true });
          break;
        }

        case 'SAVE_LOVABLE_TOKEN': {
          const token = msg.token || '';
          if (token) {
            await setSettings({ lovableToken: token, lovableTokenAt: Date.now() });
          }
          sendResponse({ ok: true });
          break;
        }

        case 'SAVE_LOVABLE_WORKSPACE_ID': {
          const wsId = msg.workspaceId || '';
          if (wsId) {
            await setSettings({ lovableWorkspaceId: wsId });
          }
          sendResponse({ ok: true });
          break;
        }

        case 'SAVE_LOVABLE_CASTLE_TOKEN': {
          const ct = msg.token || '';
          if (ct) {
            await setSettings({ lovableCastleToken: ct, lovableCastleTokenAt: Date.now() });
          }
          sendResponse({ ok: true });
          break;
        }

        case 'SAVE_LOVABLE_SESSION_HEADERS': {
          const updates = {};
          if (msg.sessionId) updates.lovableSessionId = msg.sessionId;
          if (msg.gitSha) updates.lovableClientGitSha = msg.gitSha;
          if (Object.keys(updates).length > 0) await setSettings(updates);
          sendResponse({ ok: true });
          break;
        }

        case 'GET_ACTIVE_PROJECT_ID': {
          const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
          const url = tab?.url || '';
          const m = /https:\/\/lovable\.dev\/projects\/([a-f0-9-]+)/i.exec(url);
          sendResponse({ projectId: m ? m[1] : null, url });
          break;
        }

        case 'CLEAR_CHAT_HISTORY': {
          // Sobrescreve direto via storage.local.set pra contornar o deepMerge
          // (que não consegue remover chaves de sub-objetos).
          const cur = await getSettings();
          const all = { ...(cur.tryToFixHistory || {}) };
          if (msg.projectId) {
            delete all[msg.projectId];
          } else {
            // sem projectId → limpa tudo
            Object.keys(all).forEach((k) => delete all[k]);
          }
          await chrome.storage.local.set({ settings: { ...cur, tryToFixHistory: all } });
          sendResponse({ ok: true, tryToFixHistory: all });
          break;
        }

        case 'LOG_INTEL': {
          const cur = await getSettings();
          await setSettings({ intel: { ...cur.intel, ...(msg.data || {}) } });
          sendResponse({ ok: true });
          break;
        }

        case 'LOG_FEATURE_FLAGS':
          await setSettings({ featureFlags: msg.flags || {} });
          sendResponse({ ok: true });
          break;

        case 'LOG_PROMPT': {
          const cur = await getSettings();
          const today = new Date().toISOString().slice(0, 10);
          const daily = { ...(cur.stats?.daily || {}) };
          daily[today] = (daily[today] || 0) + 1;
          // Keep only last 30 days to avoid bloating storage
          const keys = Object.keys(daily).sort();
          if (keys.length > 30) {
            keys.slice(0, keys.length - 30).forEach(k => delete daily[k]);
          }
          await setSettings({
            stats: {
              ...cur.stats,
              promptCount: (cur.stats?.promptCount || 0) + 1,
              lastPromptAt: Date.now(),
              daily,
            },
          });
          sendResponse({ ok: true });
          break;
        }

        case 'LOG_ERROR': {
          const cur = await getSettings();
          await setSettings({
            stats: { ...cur.stats, errorCount: (cur.stats?.errorCount || 0) + 1 },
          });
          sendResponse({ ok: true });
          break;
        }

        case 'RESET_STATS': {
          const updated = await setSettings({
            stats: { promptCount: 0, errorCount: 0, lastPromptAt: 0 },
          });
          sendResponse(updated);
          break;
        }

        case 'OPEN_OPTIONS':
          chrome.runtime.openOptionsPage();
          sendResponse({ ok: true });
          break;

        case 'SEND_MESSAGE_PROXY': {
          const msgText   = String(msg.message   || '');
          const projectId = String(msg.projectId || '');
          const token     = String(msg.token     || '').replace(/^Bearer\s+/i, '').trim();
          const sessionId = String(msg.sessionId || '');
          const gitSha    = String(msg.gitSha    || '');
          const msgFiles     = Array.isArray(msg.files)     ? msg.files     : [];
          const msgImageUrls = Array.isArray(msg.imageUrls) ? msg.imageUrls : [];

          if (!token || !projectId || !msgText) {
            sendResponse({ ok: false, error: 'token, projectId ou message ausente' });
            break;
          }

          const sd = await new Promise(r => chrome.storage.local.get([
            "\x6c\x6f\x76\x61\x62\x6c\x65\x5f\x63\x68\x61\x74\x5f\x70\x61\x79\x6c\x6f\x61\x64\x73",
            "\x6c\x6f\x76\x61\x62\x6c\x65\x5f\x62\x72\x6f\x77\x73\x65\x72\x5f\x73\x65\x73\x73\x69\x6f\x6e\x5f\x69\x64", 'lovable_git_sha',
          ], r));

          const captured = sd.lovable_chat_payloads || [];
          const lastCaptureFull = captured.length > 0 ? captured[captured.length - 1].body : null;

          const buildLastPayload = () => {
            const beid = `be_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
            const tpl = {
              intent: "\x66\x69\x78\x5f\x65\x72\x72\x6f\x72",
              dispatch_mode: "\x73\x65\x63\x75\x72\x69\x74\x79\x5f\x66\x69\x78",
              source: 'ext-input',
              contains_error: true,
              error_ids: [],
              message_intent_metadata: {
                fix_error_metadata: {
                  errors: [{ error_type: 'build', error_message: msgText, build_event_id: beid }]
                }
              },
              // Injeta files e imageUrls recebidos do content.js
              files: msgFiles,
              selected_elements: [],
              optimisticImageUrls: msgImageUrls,
            };
            let base = {};
            if (lastCaptureFull && typeof lastCaptureFull === 'object') {
              base = { ...lastCaptureFull };
              delete base.intent;
              delete base.dispatch_mode;
              delete base.contains_error;
              delete base.error_ids;
              delete base.message_intent_metadata;
            }
            return { ...base, ...tpl };
          };

          const PROXY_URL = atob("aHR0cHM6Ly9waHBzeXRmZ2t2ZXBlc3ZsandidS5zdXBhYmFzZS5jby9mdW5jdGlvbnMvdjEvbG92Mw==");
          const ANON_KEY  = atob("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnBjM01pT2lKemRYQmhZbUZ6WlNJc0luSmxaaUk2SW5Cb2NITjVkR1puYTNabGNHVnpkbXhxZDJKMUlpd2ljbTlzWlNJNkltRnViMjRpTENKcFlYUWlPakUzT0RFM09UazJOemNzSW1WNGNDSTZNakE1TnpNM05UWTNOMzAuZHkxTU96STJueXVuTE12T1poUjd3MXBYYmFYWTFlWFVTamQ2V1RmRzhwcw==");
          const PROXY_HEADERS = {
            'Content-Type':  'application/json',
            'apikey':        ANON_KEY,
            'Authorization': `Bearer ${ANON_KEY}`,
          };

          // Fetch com até 2 retries e 45s timeout (igual v6.2.34)
          // Regenera buildEventId a cada tentativa para evitar conflito de IDs
          let proxyResp;
          for (let attempt = 0; attempt <= 2; attempt++) {
            const ctrl = new AbortController();
            const tid  = setTimeout(() => ctrl.abort(), 45000);
            try {
              const payload = {
                token, token_lovable: token,
                projectId, projeto_id: projectId,
                message: msgText, mensagem: msgText,
                browser_session_id:         sessionId || sd.lovable_browser_session_id || undefined,
                lovable_browser_session_id: sessionId || sd.lovable_browser_session_id || undefined,
                client_git_sha:  gitSha || sd.lovable_git_sha || undefined,
                lovable_git_sha: gitSha || sd.lovable_git_sha || undefined,
                lastPayload: buildLastPayload(),
                mode: 'error',
              };
              proxyResp = await fetch(PROXY_URL, {
                method: 'POST',
                headers: PROXY_HEADERS,
                body: JSON.stringify(payload),
                signal: ctrl.signal,
              });
              clearTimeout(tid);
              // Para em sucesso, auth failure, ou última tentativa
              if (proxyResp.ok || proxyResp.status === 202) break;
              if (proxyResp.status === 401 || proxyResp.status === 403) break;
              if (attempt === 2) break;
              await new Promise(res => setTimeout(res, 1500 * (attempt + 1)));
            } catch (fetchErr) {
              clearTimeout(tid);
              if (attempt === 2) throw fetchErr;
              await new Promise(res => setTimeout(res, 1500 * (attempt + 1)));
            }
          }

          if (proxyResp.ok || proxyResp.status === 202) {
            sendResponse({ ok: true, status: proxyResp.status });
          } else {
            const errText = await proxyResp.text().catch(() => '');
            let errMsg = `Erro ${proxyResp.status}`;
            try { errMsg = JSON.parse(errText).error || errMsg; } catch {}
            sendResponse({ ok: false, status: proxyResp.status, error: errMsg });
          }
          break;
        }

        default:
          sendResponse({ ok: false, error: 'unknown: ' + msg.type });
      }
    } catch (e) {
      console.error('[PULSE bg]', e);
      sendResponse({ ok: false, error: e.message });
    }
  })();
  return true;
}

function updateBadge(settings) {
  try {
    const enabled = !!settings?.enabled;
    const status = settings?.licenseState?.status;
    if (status && status !== 'valid' && status !== 'unknown') {
      chrome.action.setBadgeText({ text: '!' });
      chrome.action.setBadgeBackgroundColor({ color: '#ef4444' });
      chrome.action.setBadgeTextColor?.({ color: '#ffffff' });
      return;
    }
    chrome.action.setBadgeText({ text: enabled ? 'on' : 'off' });
    chrome.action.setBadgeBackgroundColor({ color: enabled ? '#00CC82' : '#CC2222' });
    chrome.action.setBadgeTextColor?.({ color: '#ffffff' });
  } catch (_) {}
}

// ============================================================
// Verificação local de expiração (sem depender do servidor)
// ============================================================
async function checkLocalExpiry() {
  const cur = await getSettings();
  const expiresAt = cur.licenseState?.expiresAt;
  if (!expiresAt) return; // sem data = sem expiração local

  const now = Date.now();
  const expiresMs = new Date(expiresAt).getTime();
  if (Number.isNaN(expiresMs)) return;

  if (now >= expiresMs) {
    // EXPIROU — revoga imediatamente
    console.log('[PULSE bg] license expired locally, revoking');
    const expired = {
      ...emptyLicenseState(),
      status: 'expired',
      error: 'Licença expirada',
      lastChecked: now,
    };
    const updated = await setSettings({
      enabled: false,
      licenseState: expired,
    });
    updateBadge(updated);
    return true; // expirou
  }

  // Se falta menos de 2h, agenda alarm pra checar a cada 5 min
  const remaining = expiresMs - now;
  if (remaining < 2 * 3600 * 1000) {
    chrome.alarms?.create('license-expiry-watch', { periodInMinutes: 5 });
  }

  return false;
}

// Side panel: clique no ícone da extensão abre o painel lateral direito.
try {
  chrome.sidePanel?.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
} catch (_) {}

chrome.runtime.onInstalled.addListener(async () => {
  const s = await getSettings();
  updateBadge(s);
  await checkLocalExpiry();
  try { chrome.sidePanel?.setPanelBehavior({ openPanelOnActionClick: true }); } catch (_) {}

  // Gera HWID único na instalação (1 vez por dispositivo)
  if (!s.deviceId) {
    const deviceId = crypto.randomUUID();
    await setSettings({ deviceId });
    console.log('[LOV] HWID gerado:', deviceId);
  }

  // Polling de licença a cada 1 minuto
  chrome.alarms?.create('license-revalidate', { periodInMinutes: 1 });
});

chrome.runtime.onStartup?.addListener(async () => {
  const s = await getSettings();
  updateBadge(s);
  await checkLocalExpiry();
  try { chrome.sidePanel?.setPanelBehavior({ openPanelOnActionClick: true }); } catch (_) {}
  chrome.alarms?.create('license-revalidate', { periodInMinutes: 1 });
});

chrome.alarms?.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'license-expiry-watch') {
    // Check rápido local — sem bater no servidor
    const expired = await checkLocalExpiry();
    if (expired) {
      // Para o watch, já expirou
      chrome.alarms?.clear('license-expiry-watch');
    }
    return;
  }

  if (alarm.name !== 'license-revalidate') return;

  // Primeiro: check local (instantâneo, sem rede)
  const localExpired = await checkLocalExpiry();
  if (localExpired) {
    // Já revogou localmente — notifica popup imediatamente
    broadcastLicenseRevoked();
    return;
  }

  // Depois: revalida com o servidor (toda vez, cache TTL = 1 min)
  const cur = await getSettings();
  if (!cur.licenseKey) return;

  const state = await validateLicense(cur.licenseKey, cur.userEmail, cur.deviceId).catch(() => null);
  if (!state) return; // erro de rede — não revoga por falta de conexão

  if (state.status !== 'valid') {
    // Licença revogada/expirada/inválida — desconecta imediatamente
    const updated = await setSettings({ enabled: false, licenseState: state });
    updateBadge(updated);
    broadcastLicenseRevoked();
    console.log('[LOV] licença inválida detectada no polling:', state.status, state.error);
  } else {
    updateBadge(await getSettings());
  }
});

// Notifica todos os popups/sidepanels abertos para forçar render() imediato.
// Como o popup já escuta chrome.storage.onChanged, o setSettings acima já
// dispara o render — este broadcast é um reforço para garantir o feedback.
function broadcastLicenseRevoked() {
  chrome.runtime.sendMessage({ type: 'LICENSE_REVOKED' }).catch(() => {
    // popup pode não estar aberto — normal, ignora
  });
}

chrome.commands?.onCommand.addListener(async (command) => {
  if (command !== 'toggle-enabled') return;
  // Reusa a mesma lógica do TOGGLE_ENABLED.
  const cur = await getSettings();
  if (!cur.enabled) {
    const state = await getLicenseState({ force: true });
    if (state.status !== 'valid') {
      updateBadge(await setSettings({ enabled: false }));
      return;
    }
  }
  updateBadge(await setSettings({ enabled: !cur.enabled }));
});


// ── Captura payloads nativos do Lovable (metodologia v6.2.34) ──────────────
// Intercepta POST para api.lovable.dev/projects/*/chat ANTES de sair.
// Salva em lovable_chat_payloads para merge com fix_error no handleSendTryToFix.
try {
  chrome.webRequest.onBeforeRequest.addListener(
    (details) => {
      if (details.method !== 'POST') return;
      if (!details.requestBody || !details.requestBody.raw) return;
      try {
        const bytes = details.requestBody.raw[0] && details.requestBody.raw[0].bytes;
        if (!bytes) return;
        const text = new TextDecoder('utf-8').decode(bytes);
        if (!text || text.length < 10) return;
        const data = JSON.parse(text);
        if (!data || typeof data !== 'object') return;
        // Captura ai_message_id para uso nos campos de bypass
        if (data.ai_message_id && typeof data.ai_message_id === 'string') {
          chrome.storage.local.set({ lovable_last_aimsg: data.ai_message_id });
        }
        // Salva payload completo — usado no merge fix_error
        const entry = { timestamp: Date.now(), url: details.url, body: data };
        chrome.storage.local.get({ lovable_chat_payloads: [] }, (stored) => {
          const arr = stored.lovable_chat_payloads || [];
          arr.push(entry);
          if (arr.length > 20) arr.splice(0, arr.length - 20);
          chrome.storage.local.set({ lovable_chat_payloads: arr });
        });
      } catch (_) {}
    },
    { urls: ['https://api.lovable.dev/projects/*/chat'] },
    ['requestBody']
  );
  console.log('[LOV bg] onBeforeRequest ativo — captura payload nativo do chat');
} catch (e) {
  console.warn('[LOV bg] onBeforeRequest indisponível:', e?.message);
}
