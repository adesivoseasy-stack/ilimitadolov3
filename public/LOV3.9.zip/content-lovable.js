﻿/**
 * Content script — injeta em https://lovable.dev/*
 * Captura o projectId da URL e notifica o background quando muda (SPA).
 * O token de Bearer é capturado pelo background via webRequest.
 * Privacidade: nunca lê conteúdo da página, só a URL.
 */
;(function () {
  // ── Captura projectId ───────────────────────────────────────────────────────
  function notificarProjeto () {
    var m = /\/projects\/([a-f0-9-]{36})/i.exec(location.href)
    if (m) {
      chrome.runtime.sendMessage({ tipo: 'lovable_page', projectId: m[1] })
        .catch(function () {})
    }
  }

  notificarProjeto()

  var lastHref = location.href
  var urlObserver = new MutationObserver(function () {
    if (location.href !== lastHref) {
      lastHref = location.href
      notificarProjeto()
    }
  })
  urlObserver.observe(document, { subtree: true, childList: true })

  // ── Rebrand DOM: troca textos da Lovable por "LOV3" ──────────────────────────
  // Anti-loop: WeakSet impede reprocessar o mesmo nó; sem characterData no observer;
  // throttle de 30 trocas/s (pausa 3s se ultrapassar) evita loop com reconciliation React.
  ;(function setupRebrand() {
    var PATTERNS = [
      /^Fast Visual Edit$/i,
      /^Visual Edit$/i,
      /^Fast Edit$/i,
      /^Pulse Mode$/i,
      /^Fix error$/i,
      /^Fix Error$/i,
      /^Fix build error$/i,
      /^Security review$/i,
      /^security_fix$/i,
      /^fix_error$/i,
    ]
    var REPLACEMENT = 'LOV3'

    var _seen       = new WeakSet()
    var _mods       = 0
    var _winStart   = Date.now()
    var _paused     = false

    function tryReplace(node) {
      if (!node || node.nodeType !== Node.TEXT_NODE) return
      if (_seen.has(node)) return
      if (_paused) return
      var txt = node.textContent
      if (!txt) return
      var trimmed = txt.trim()
      if (!trimmed || trimmed === REPLACEMENT) { _seen.add(node); return }
      for (var i = 0; i < PATTERNS.length; i++) {
        if (PATTERNS[i].test(trimmed)) {
          var now = Date.now()
          if (now - _winStart > 1000) { _winStart = now; _mods = 0 }
          _mods++
          if (_mods > 30) {
            _paused = true
            setTimeout(function() { _paused = false; _mods = 0 }, 3000)
            return
          }
          _seen.add(node)
          var leading  = (txt.match(/^\s*/) || [''])[0]
          var trailing = (txt.match(/\s*$/) || [''])[0]
          node.textContent = leading + REPLACEMENT + trailing
          return
        }
      }
    }

    function scanSubtree(root) {
      if (!root) return
      if (root.nodeType === Node.TEXT_NODE) { tryReplace(root); return }
      if (root.nodeType !== Node.ELEMENT_NODE) return
      var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT)
      var n
      while ((n = walker.nextNode())) tryReplace(n)
    }

    function start() {
      scanSubtree(document.body)
      var obs = new MutationObserver(function(muts) {
        for (var i = 0; i < muts.length; i++) {
          var m = muts[i]
          if (m.type === 'childList') {
            for (var j = 0; j < m.addedNodes.length; j++) {
              scanSubtree(m.addedNodes[j])
            }
          }
        }
      })
      // SEM characterData — evita loop com reconciliation React
      obs.observe(document.body, { childList: true, subtree: true })
    }

    if (document.body) start()
    else document.addEventListener('DOMContentLoaded', start)
  })()
})()