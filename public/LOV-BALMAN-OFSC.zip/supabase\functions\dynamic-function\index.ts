import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

function jsonResp(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS, "Content-Type": "application/json" },
  });
}

function lovId(prefix: string): string {
  const hex = crypto.randomUUID().replace(/-/g, "");
  return `${prefix}_${hex.substring(0, 26)}`;
}

serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });

  try {
    const body = await req.json();

    const token     = String(body.token_lovable || body.token || "").replace(/^Bearer\s+/i, "").trim();
    const projectId = String(body.projeto_id   || body.projectId || "");
    const message   = String(body.mensagem     || body.message   || "");

    const browserSessionId = String(
      body.browser_session_id || body.lovable_browser_session_id || body.sessionId || ""
    ).trim();
    const clientGitSha = String(
      body.client_git_sha || body.lovable_git_sha || body.gitSha || ""
    ).trim();

    const lastPayload = (body.lastPayload && typeof body.lastPayload === "object")
      ? body.lastPayload as Record<string, unknown>
      : null;

    if (!token || !projectId || !message) {
      return jsonResp({ error: "token, projectId e message são obrigatórios" }, 400);
    }

    console.log("[dynamic-function] project:", projectId.slice(0, 8),
      "| lastPayload:", !!lastPayload,
      "| session:", !!browserSessionId);

    let chatBody: Record<string, unknown>;

    if (lastPayload) {
      // Modo v6.2.34: spread do payload nativo + overrides mínimos (igual dynamic-api-v2-leigos).
      // NÃO sobrescreve contains_error, error_ids, message_intent_metadata —
      // o background.js já os preparou corretamente dentro de lastPayload.
      // ai_message_id SEMPRE gerado fresh — nunca reutilizar ID já usado.
      chatBody = {
        ...lastPayload,
        id:            lovId("umsg"),
        ai_message_id: lovId("aimsg"),
        message,
        intent:        "fix_error",
        dispatch_mode: "security_fix",
        source:        "ext-input",
      };
      console.log("[dynamic-function] modo: v6234-lastPayload | dispatch:", chatBody.dispatch_mode,
        "| contains_error:", chatBody.contains_error);
    } else {
      // Modo legado: payload completo com error_type:build + dispatch_mode:security_fix
      const buildEventId = `be_${Date.now().toString(36)}_${crypto.randomUUID().replace(/-/g,"").slice(0,8)}`;
      chatBody = {
        id:            lovId("umsg"),
        ai_message_id: lovId("aimsg"),
        message,
        intent:        "fix_error",
        dispatch_mode: "security_fix",
        source:        "ext-input",
        message_intent_metadata: {
          fix_error_metadata: {
            errors: [{
              error_type:     "build",
              error_message:  message,
              build_event_id: buildEventId,
            }],
          },
        },
        contains_error:       true,
        error_ids:            [],
        session_replay:       "",
        client_logs:          [],
        network_requests:     [],
        runtime_errors:       [],
        integration_metadata: { browser: {} },
        files:                [],
        selected_elements:    [],
        chat_only:            false,
        optimisticImageUrls:  [],
        thread_id:            "main",
        current_page:         "/",
        current_viewport_width:  1280,
        current_viewport_height: 800,
        current_viewport_dpr:    1,
        view:                 "preview",
        view_description:     "The user is currently viewing the preview. ",
        model:                null,
      };
      console.log("[dynamic-function] modo: legacy fix_error (build+security_fix)");
    }

    const chatHeaders: Record<string, string> = {
      "Authorization": `Bearer ${token}`,
      "Content-Type":  "application/json",
      "Origin":        "https://lovable.dev",
      "Referer":       "https://lovable.dev/",
    };
    if (browserSessionId) chatHeaders["x-browser-session-id"] = browserSessionId;
    if (clientGitSha)     chatHeaders["x-client-git-sha"]     = clientGitSha;

    const chatUrl = `https://api.lovable.dev/projects/${projectId}/chat`;
    console.log("[dynamic-function] → Lovable | intent:", chatBody.intent,
      "| dispatch:", chatBody.dispatch_mode);

    const chatResp = await fetch(chatUrl, {
      method: "POST",
      headers: chatHeaders,
      body: JSON.stringify(chatBody),
    });

    const chatText = await chatResp.text().catch(() => "");
    console.log("[dynamic-function] Lovable status:", chatResp.status,
      "| body:", chatText.slice(0, 200));

    if (chatResp.ok || chatResp.status === 202) {
      return jsonResp({ ok: true, status: chatResp.status, via: "fix_error" });
    }

    if (chatResp.status === 401 || chatResp.status === 403) {
      return jsonResp({
        ok: false,
        error: `Token inválido (${chatResp.status}). Recarregue a aba do Lovable.`,
      }, 401);
    }

    return jsonResp({
      ok: false,
      error: `Lovable rejeitou (${chatResp.status}). Detail: ${chatText.slice(0, 200)}`,
    }, chatResp.status >= 500 ? 502 : 400);

  } catch (err) {
    console.error("[dynamic-function] erro:", err);
    return jsonResp({ error: String(err) }, 500);
  }
});
