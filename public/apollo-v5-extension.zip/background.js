// Background service worker - Apollo Extension v5

chrome.action.onClicked.addListener(async (tab) => {
  await chrome.sidePanel.open({ tabId: tab.id });
});

chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });

// ========== INTERCEPT LOVABLE API TOKEN (webRequest) ==========
chrome.webRequest.onSendHeaders.addListener(
  (details) => {
    if (!details.requestHeaders) return;
    
    let apiToken = null;
    let gitSha = null;
    
    for (const header of details.requestHeaders) {
      const name = header.name.toLowerCase();
      if (name === 'authorization' && header.value) {
        apiToken = header.value;
      }
      if (name === 'x-client-git-sha' && header.value) {
        gitSha = header.value;
      }
    }
    
    if (apiToken) {
      const dataToStore = { lovable_api_token: apiToken, lovable_api_token_ts: Date.now() };
      if (gitSha) dataToStore.lovable_git_sha = gitSha;
      chrome.storage.local.set(dataToStore);
      console.log('[Apollo-BG] 🔑 Captured Lovable API token via webRequest');
    }
  },
  { urls: ["https://api.lovable.dev/*"] },
  ["requestHeaders"]
);

// Listen for messages
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'openUrl' && message.url) {
    chrome.tabs.create({ url: message.url });
    sendResponse({ success: true });
    return true;
  }

  if (message.action === 'chatCaptured') {
    chrome.runtime.sendMessage({
      action: 'chatCapturedRelay',
      content: message.content,
      source: message.source || 'dom',
      timestamp: message.timestamp
    }).catch(() => {});
    sendResponse({ ok: true });
    return true;
  }

  if (message.action === 'tokenCaptured') {
    console.log('[Apollo-BG] 🔑 Token captured via content script intercept');
    chrome.runtime.sendMessage({
      action: 'tokenCapturedRelay',
      token: message.token,
      gitSha: message.gitSha
    }).catch(() => {});
    sendResponse({ ok: true });
    return true;
  }

  // Download project source-code
  if (message.action === 'downloadSourceCode') {
    const { projectId, token } = message;
    console.log('[Apollo-BG] 📦 Fetching source-code for project:', projectId);

    fetch(`https://lovable-api.com/projects/${projectId}/source-code`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Accept': 'application/json'
      }
    })
    .then(response => {
      if (!response.ok) throw new Error(`API returned ${response.status}`);
      return response.json();
    })
    .then(data => {
      const files = Array.isArray(data) ? data : (data.files || data.data || []);
      sendResponse({ success: true, files });
    })
    .catch(error => {
      sendResponse({ success: false, error: error.message });
    });

    return true;
  }

  // Fetch a single raw file
  if (message.action === 'fetchRawFile') {
    const { projectId, filePath, token } = message;

    fetch(`https://api.lovable.dev/projects/${projectId}/files/raw?path=${encodeURIComponent(filePath)}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Accept': '*/*'
      }
    })
    .then(async (response) => {
      if (!response.ok) {
        sendResponse({ success: false, error: `HTTP ${response.status}` });
        return;
      }
      const contentType = response.headers.get('content-type') || '';
      if (contentType.includes('text') || contentType.includes('json') || contentType.includes('javascript') || contentType.includes('xml') || contentType.includes('svg')) {
        const text = await response.text();
        sendResponse({ success: true, data: text, type: 'text' });
      } else {
        const buffer = await response.arrayBuffer();
        const bytes = new Uint8Array(buffer);
        let binary = '';
        for (let i = 0; i < bytes.length; i++) {
          binary += String.fromCharCode(bytes[i]);
        }
        const base64 = btoa(binary);
        sendResponse({ success: true, data: base64, type: 'binary' });
      }
    })
    .catch(error => {
      sendResponse({ success: false, error: error.message });
    });

    return true;
  }

  // Revert project
  if (message.action === 'revertToEdit') {
    const { projectId, messageId, restoreDatabase, token, gitSha } = message;

    const authHeader = token.startsWith('Bearer') ? token : `Bearer ${token}`;

    chrome.storage.local.get(['lovable_git_sha'], (stored) => {
      const headers = {
        'Content-Type': 'application/json',
        'Authorization': authHeader,
        'origin': 'https://lovable.dev',
        'referer': 'https://lovable.dev/'
      };
      const effectiveGitSha = gitSha || stored.lovable_git_sha;
      if (effectiveGitSha) {
        headers['x-client-git-sha'] = effectiveGitSha;
      }

      fetch(`https://api.lovable.dev/projects/${projectId}/revert-to-edit`, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          message_id: messageId,
          restore_database: restoreDatabase || false
        })
      })
      .then(async (response) => {
        const text = await response.text();
        if (!response.ok) {
          sendResponse({ success: false, error: `HTTP ${response.status}: ${text.substring(0, 100)}` });
          return;
        }
        let data;
        try { data = JSON.parse(text); } catch { data = { raw: text }; }
        sendResponse({ success: true, data });
      })
      .catch(error => {
        sendResponse({ success: false, error: error.message });
      });
    });

    return true;
  }
});