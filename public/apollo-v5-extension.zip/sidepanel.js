// ============================================================
// APOLLO Extension v5.1.1 - THIN CLIENT SHELL (Orange Theme)
// ============================================================

const EXTENSION_VERSION = '5.1.1';
console.log(`🚀 Apollo Extension v${EXTENSION_VERSION} (Thin Client) iniciando...`);

const SUPABASE_URL = 'https://rmetppilvfrxosvxzhgj.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJtZXRwcGlsdmZyeG9zdnh6aGdqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzAwNjE2MzgsImV4cCI6MjA4NTYzNzYzOH0.9ClXH2tomnJAGf0BSTAsJ7v4DTfnKQ8DDcrFj8mbqxY';
const REMOTE_ORIGIN = SUPABASE_URL;

let licenseSessionToken = null;
let licenseKey = null;
let licenseInfo = null;
let cachedHwid = null;

// ========== UTILITY FUNCTIONS ==========

function showToast(message, type = 'success') {
  const toast = document.getElementById('toast');
  if (!toast) return;
  toast.textContent = message;
  toast.className = 'toast ' + type;
  toast.offsetHeight;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 2500);
}

async function generateHWID() {
  if (cachedHwid) return cachedHwid;
  const stored = await chrome.storage.local.get(['hwid']);
  if (stored.hwid) { cachedHwid = stored.hwid; return stored.hwid; }
  const components = [
    navigator.userAgent, navigator.language, navigator.platform,
    screen.width + 'x' + screen.height, screen.colorDepth,
    new Date().getTimezoneOffset(), navigator.hardwareConcurrency || 'unknown'
  ];
  const data = components.join('|');
  const hashBuffer = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(data));
  cachedHwid = Array.from(new Uint8Array(hashBuffer)).map(b => b.toString(16).padStart(2, '0')).join('');
  await chrome.storage.local.set({ hwid: cachedHwid });
  return cachedHwid;
}

async function validateLicense(key) {
  try {
    console.log('🔐 [Apollo] Validando licença:', key.substring(0, 8) + '***');
    const response = await fetch(`${SUPABASE_URL}/functions/v1/validate-license`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${SUPABASE_ANON_KEY}`, 'apikey': SUPABASE_ANON_KEY },
      body: JSON.stringify({ license_key: key })
    });
    return await response.json();
  } catch (error) {
    console.error('❌ [Apollo] Erro ao validar licença:', error);
    return { status: 'error', message: error.message };
  }
}

async function revalidateLicense() {
  if (!licenseKey) {
    const storage = await chrome.storage.local.get(['licenseKey']);
    licenseKey = storage.licenseKey;
  }
  if (!licenseKey) return { valid: false, message: 'Nenhuma licença ativada' };
  const result = await validateLicense(licenseKey);
  if (result.status === 'valid') {
    licenseSessionToken = result.session_token;
    await chrome.storage.local.set({ licenseSessionToken: result.session_token });
    licenseInfo = { days_remaining: result.days_remaining, hours_remaining: result.hours_remaining, license_id: result.license_id };
    return { valid: true, session_token: result.session_token };
  }
  return { valid: false, message: result.message };
}


// ========== CHROME API HELPERS ==========

async function getAuthData() {
  try {
    const stored = await chrome.storage.local.get(['lovable_api_token', 'lovable_api_token_ts', 'lovable_git_sha']);
    if (stored.lovable_api_token) {
      const age = Date.now() - (stored.lovable_api_token_ts || 0);
      if (age < 3600000) {
        const rawToken = stored.lovable_api_token.replace(/^Bearer\s+/i, '');
        return { token: rawToken, sessionId: null, gitSha: stored.lovable_git_sha || null, source: 'webRequest' };
      }
    }
    const cookies = await chrome.cookies.getAll({ domain: 'lovable.dev' });
    let token = null, sessionId = null;
    for (const cookie of cookies) {
      if (cookie.name === 'lovable-session-id.id' && !token) {
        token = cookie.value;
        try {
          const parts = cookie.value.split('.');
          if (parts.length === 3) {
            const payload = JSON.parse(atob(parts[1]));
            sessionId = payload.user_id || payload.sub || payload.session_id;
          }
        } catch {}
      }
      if (cookie.name === 'sb-api-auth-token' && !token) {
        try { const p = JSON.parse(decodeURIComponent(cookie.value)); token = p.access_token || p[0]?.access_token || cookie.value; } catch { token = cookie.value; }
      }
      if (!sessionId && cookie.name.includes('session')) {
        try { const p = JSON.parse(decodeURIComponent(cookie.value)); sessionId = p.session_id || p[0]?.session_id; } catch {}
      }
    }
    return { token, sessionId, gitSha: null, source: 'cookies' };
  } catch (e) {
    return { token: null, sessionId: null, gitSha: null, source: 'error' };
  }
}

async function getProjectFromActiveTab() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.url) return null;
    const match = tab.url.match(/lovable\.dev\/projects\/([a-f0-9-]+)/);
    if (match) return match[1];
    const subdomainMatch = tab.url.match(/([a-f0-9-]+)\.lovableproject\.com/);
    if (subdomainMatch) return subdomainMatch[1];
    return null;
  } catch { return null; }
}

// ========== BRIDGE ==========

function setupBridge(iframe) {
  window.addEventListener('message', async (event) => {
    const { requestId, command, payload } = event.data || {};
    if (!requestId || !command) return;

    console.log(`[Apollo-Bridge] Command: ${command}`, payload);

    let result = null;
    let error = null;

    try {
      switch (command) {
        case 'storage.get': {
          result = await chrome.storage.local.get(payload?.keys || []);
          break;
        }
        case 'storage.set': {
          await chrome.storage.local.set(payload?.data || {});
          result = { ok: true };
          break;
        }
        case 'cookies.getAll': {
          result = await chrome.cookies.getAll({ domain: payload?.domain || 'lovable.dev' });
          break;
        }
        case 'tabs.query': {
          result = await chrome.tabs.query(payload?.queryInfo || { active: true, currentWindow: true });
          break;
        }
        case 'auth.getToken': {
          result = await getAuthData();
          break;
        }
        case 'project.getActive': {
          result = { projectId: await getProjectFromActiveTab() };
          break;
        }
        case 'license.getInfo': {
          result = { licenseInfo, licenseSessionToken, licenseKey };
          break;
        }
        case 'license.revalidate': {
          result = await revalidateLicense();
          break;
        }
        case 'license.logout': {
          await chrome.storage.local.remove(['licenseKey', 'licenseSessionToken']);
          licenseKey = null;
          licenseSessionToken = null;
          licenseInfo = null;
          showLicenseScreen();
          result = { ok: true };
          break;
        }
        case 'lovable.sendMessage': {
          const pId = payload?.projectId || await getProjectFromActiveTab();
          if (!pId) { error = 'Abra um projeto no Lovable.dev primeiro'; break; }
          const check = await revalidateLicense();
          if (!check.valid) { error = check.message || 'Licença inválida'; break; }
          let lovableToken = null;
          try { const stored = await chrome.storage.local.get(['lovable_api_token']); lovableToken = stored.lovable_api_token || null; } catch {}
          const sendPayload = { token: lovableToken || '', projectId: pId, message: payload?.message || '' };
          const files = payload?.files;
          if (files && files.length > 0) {
            sendPayload.files = files.slice(0, 10).map(f => ({
              data: f.data.split(',')[1] || f.data,
              name: f.name || 'file',
              type: f.type || 'application/octet-stream',
            }));
          }
          let response;
          try {
            response = await fetch(`${SUPABASE_URL}/functions/v1/send-message`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
                'apikey': SUPABASE_ANON_KEY,
                'x-session-token': licenseSessionToken || ''
              },
              body: JSON.stringify(sendPayload)
            });
          } catch (fetchErr) {
            error = `Failed to fetch: ${fetchErr.message}`;
            break;
          }
          if (!response.ok) {
            const errBody = await response.text();
            try { const parsed = JSON.parse(errBody); error = parsed.message || `Erro HTTP ${response.status}`; } catch { error = `Erro HTTP ${response.status}`; }
            break;
          }
          const responseText = await response.text();
          if (!responseText || responseText.trim() === '') {
            result = { message: '✅ Mensagem enviada! O n8n está processando...' };
          } else {
            const ct = response.headers.get('content-type') || '';
            if (ct.includes('application/json')) {
              try { result = JSON.parse(responseText); } catch { result = { reply: responseText }; }
            } else { result = { reply: responseText }; }
          }
          break;
        }
        case 'lovable.publish': {
          const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
          if (!tab?.url?.includes('lovable.dev')) { error = 'Você precisa estar no Lovable.dev!'; break; }
          const pId2 = await getProjectFromActiveTab();
          if (!pId2) { error = 'Abra um projeto no Lovable.dev primeiro'; break; }
          const auth2 = await getAuthData();
          result = await new Promise((resolve) => {
            chrome.tabs.sendMessage(tab.id, { action: 'publishProject', projectId: pId2, authToken: auth2.token }, (response) => {
              if (chrome.runtime.lastError) resolve({ success: false, error: 'Erro ao publicar.' });
              else resolve(response || { success: true });
            });
          });
          break;
        }
        case 'templates.getAll': {
          const tplResponse = await fetch(`${SUPABASE_URL}/functions/v1/get-templates`, {
            method: 'GET',
            headers: { 'Authorization': `Bearer ${SUPABASE_ANON_KEY}`, 'apikey': SUPABASE_ANON_KEY, 'x-session-token': licenseSessionToken }
          });
          if (!tplResponse.ok) throw new Error(`HTTP ${tplResponse.status}`);
          result = await tplResponse.json();
          break;
        }
        case 'lovable.downloadProject': {
          const auth = await getAuthData();
          const pId3 = payload?.projectId || await getProjectFromActiveTab();
          if (!auth.token) { error = 'Token não encontrado. Faça login no Lovable.dev'; break; }
          if (!pId3) { error = 'Abra um projeto no Lovable.dev primeiro'; break; }
          const check3 = await revalidateLicense();
          if (!check3.valid) { error = check3.message || 'Licença inválida'; break; }
          const sendProgress = (msg) => {
            iframe.contentWindow?.postMessage({ requestId: 'progress_' + Date.now(), command: 'download.progress', payload: { message: msg } }, '*');
          };
          sendProgress('📡 Buscando arquivos do projeto...');
          const sourceResult = await new Promise((resolve) => {
            chrome.runtime.sendMessage({ action: 'downloadSourceCode', projectId: pId3, token: auth.token }, (response) => resolve(response));
          });
          if (!sourceResult?.success || !sourceResult.files) { error = sourceResult?.error || 'Falha ao obter código-fonte'; break; }
          const dlFiles = sourceResult.files;
          sendProgress(`📦 Empacotando ${dlFiles.length} arquivos...`);
          const zip = new JSZip();
          const IMAGE_EXT = /\.(png|jpg|jpeg|gif|svg|ico|webp|bmp|zip|woff|woff2|ttf|eot|mp3|mp4|pdf)$/i;
          const binaryFiles = [];
          for (const file of dlFiles) {
            const filePath = file.path || file.name || file.filename;
            if (!filePath) continue;
            const content = file.contents ?? file.content ?? file.code ?? file.text ?? file.body;
            if (content != null && typeof content === 'string' && content.length > 0) {
              if (file.binary) zip.file(filePath, content, { base64: true });
              else zip.file(filePath, content);
            } else if (file.sizeExceeded) {
              console.warn('[Apollo-Download] Skipping oversized file:', filePath);
            } else if (IMAGE_EXT.test(filePath) || content == null) {
              binaryFiles.push(filePath);
            }
          }
          if (binaryFiles.length > 0) {
            sendProgress(`⬇️ Baixando ${binaryFiles.length} assets...`);
            const BATCH = 10;
            for (let i = 0; i < binaryFiles.length; i += BATCH) {
              const batch = binaryFiles.slice(i, i + BATCH);
              const results = await Promise.allSettled(batch.map(fp =>
                new Promise((resolve) => {
                  chrome.runtime.sendMessage({ action: 'fetchRawFile', projectId: pId3, filePath: fp, token: auth.token }, (res) => resolve({ path: fp, ...res }));
                })
              ));
              for (const r of results) {
                if (r.status === 'fulfilled' && r.value.success) {
                  const v = r.value;
                  if (v.type === 'binary') zip.file(v.path, v.data, { base64: true });
                  else zip.file(v.path, v.data);
                }
              }
            }
          }
          sendProgress('🗜️ Gerando ZIP...');
          const blob = await zip.generateAsync({ type: 'blob', compression: 'DEFLATE', compressionOptions: { level: 6 } });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `projeto-${pId3.slice(0, 8)}.zip`;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          setTimeout(() => URL.revokeObjectURL(url), 5000);
          result = { success: true, fileCount: dlFiles.length };
          break;
        }
        default: {
          error = `Unknown command: ${command}`;
        }
      }
    } catch (e) {
      error = e.message;
    }

    iframe.contentWindow?.postMessage({ requestId, result, error }, '*');
  });
}

// ========== SCREEN MANAGEMENT ==========

function showLicenseScreen() {
  document.getElementById('licenseScreen').style.display = 'flex';
  document.getElementById('remoteUiRoot').style.display = 'none';
}

function showRemoteUI() {
  document.getElementById('licenseScreen').style.display = 'none';
  const root = document.getElementById('remoteUiRoot');
  root.style.display = 'block';

  if (!root.querySelector('iframe')) {
    const iframe = document.createElement('iframe');
    // Load remote UI from Edge Function (apollo variant)
    iframe.src = `${SUPABASE_URL}/functions/v1/serve-extension-ui?sessionToken=${encodeURIComponent(licenseSessionToken)}&extVersion=${EXTENSION_VERSION}&brand=apollo`;
    iframe.setAttribute('sandbox', 'allow-scripts allow-same-origin allow-forms allow-popups');
    root.appendChild(iframe);
    setupBridge(iframe);
  }
}

// ========== INIT ==========

document.addEventListener('DOMContentLoaded', async () => {
  const licenseInput = document.getElementById('licenseKey');
  const activateBtn = document.getElementById('activateBtn');

  // Check stored license
  const stored = await chrome.storage.local.get(['licenseKey', 'licenseSessionToken']);
  if (stored.licenseKey) {
    licenseKey = stored.licenseKey;
    licenseSessionToken = stored.licenseSessionToken;

    const result = await validateLicense(licenseKey);
    if (result.status === 'valid') {
      licenseSessionToken = result.session_token;
      licenseInfo = { days_remaining: result.days_remaining, hours_remaining: result.hours_remaining, license_id: result.license_id };
      await chrome.storage.local.set({ licenseSessionToken: result.session_token });
      showRemoteUI();
      return;
    }
  }

  showLicenseScreen();

  // Activate button
  if (activateBtn) {
    activateBtn.addEventListener('click', async () => {
      const key = licenseInput.value.trim().toUpperCase();
      if (!key) {
        document.getElementById('licenseStatus').textContent = 'Digite uma chave de licença';
        document.getElementById('licenseStatus').style.color = '#ef4444';
        return;
      }

      activateBtn.disabled = true;
      activateBtn.textContent = 'Validando...';
      document.getElementById('licenseStatus').textContent = 'Conectando...';
      document.getElementById('licenseStatus').style.color = '#c8a07a';

      const result = await validateLicense(key);

      if (result.status === 'valid') {
        licenseKey = key;
        licenseSessionToken = result.session_token;
        licenseInfo = { days_remaining: result.days_remaining, hours_remaining: result.hours_remaining, license_id: result.license_id };

        await chrome.storage.local.set({
          licenseKey: key,
          licenseSessionToken: result.session_token
        });

        document.getElementById('licenseStatus').textContent = '✓ Licença ativada!';
        document.getElementById('licenseStatus').style.color = '#22c55e';
        activateBtn.textContent = 'Ativado!';

        setTimeout(() => showRemoteUI(), 800);
      } else {
        activateBtn.disabled = false;
        activateBtn.textContent = 'Ativar Licença';
        const msgs = {
          'not_found': 'Chave não encontrada',
          'expired': 'Licença expirada',
          'revoked': 'Licença revogada',
          'device_mismatch': 'Licença em uso em outro dispositivo',
          'error': result.message || 'Erro ao validar'
        };
        document.getElementById('licenseStatus').textContent = msgs[result.status] || result.message || 'Erro';
        document.getElementById('licenseStatus').style.color = '#ef4444';
      }
    });
  }

  // Enter key
  if (licenseInput) {
    licenseInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') activateBtn?.click();
    });
  }
});