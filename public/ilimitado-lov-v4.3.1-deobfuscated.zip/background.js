chrome.action.onClicked.addListener(async c => {
  await chrome.sidePanel.open({
    tabId: c.id
  });
});
chrome.sidePanel.setPanelBehavior({
  openPanelOnActionClick: true
});
chrome.webRequest.onSendHeaders.addListener(c => {
  if (!c.requestHeaders) {
    return;
  }
  let d = null;
  let e = null;
  for (const f of c.requestHeaders) {
    const g = f.name.toLowerCase();
    if (g === "authorization" && f.value) {
      d = f.value;
    }
    if (g === "x-client-git-sha" && f.value) {
      e = f.value;
    }
  }
  if (d) {
    const h = {
      lovable_api_token: d,
      lovable_api_token_ts: Date.now()
    };
    if (e) {
      h.lovable_git_sha = e;
    }
    chrome.storage.local.set(h);
    console.log("[Background] 🔑 Captured Lovable API token via webRequest");
  }
}, {
  urls: ["https://api.lovable.dev/*"]
}, ["requestHeaders"]);
chrome.runtime.onMessage.addListener((c, d, e) => {
  if (c.action === "openUrl" && c.url) {
    chrome.tabs.create({
      url: c.url
    });
    e({
      success: true
    });
    return true;
  }
  if (c.action === "chatCaptured") {
    chrome.runtime.sendMessage({
      action: "chatCapturedRelay",
      content: c.content,
      source: c.source || "dom",
      timestamp: c.timestamp
    }).catch(() => {});
    e({
      ok: true
    });
    return true;
  }
  if (c.action === "tokenCaptured") {
    chrome.runtime.sendMessage({
      action: "tokenCapturedRelay",
      token: c.token,
      gitSha: c.gitSha
    }).catch(() => {});
    e({
      ok: true
    });
    return true;
  }
  if (c.action === "suggestionsCaptured") {
    chrome.runtime.sendMessage({
      action: "suggestionsCapturedRelay",
      items: c.items || []
    }).catch(() => {});
    e({
      ok: true
    });
    return true;
  }
  if (c.action === "downloadSourceCode") {
    const {
      projectId: f,
      token: g
    } = c;
    console.log("[Background] 📦 Fetching source-code for project:", f);
    fetch("https://lovable-api.com/projects/" + f + "/source-code", {
      method: "GET",
      headers: {
        Authorization: "Bearer " + g,
        Accept: "application/json"
      }
    }).then(h => {
      console.log("[Background] source-code status:", h.status);
      if (!h.ok) {
        throw new Error("API returned " + h.status);
      }
      return h.json();
    }).then(h => {
      const i = Array.isArray(h) ? h : h.files || h.data || [];
      console.log("[Background] ✅ Got", i.length, "files");
      e({
        success: true,
        files: i
      });
    }).catch(h => {
      console.error("[Background] ❌ Source-code fetch failed:", h);
      e({
        success: false,
        error: h.message
      });
    });
    return true;
  }
  if (c.action === "fetchRawFile") {
    const {
      projectId: h,
      filePath: i,
      token: j
    } = c;
    fetch("https://api.lovable.dev/projects/" + h + "/files/raw?path=" + encodeURIComponent(i), {
      method: "GET",
      headers: {
        Authorization: "Bearer " + j,
        Accept: "*/*"
      }
    }).then(async k => {
      if (!k.ok) {
        e({
          success: false,
          error: "HTTP " + k.status
        });
        return;
      }
      const l = k.headers.get("content-type") || "";
      if (l.includes("text") || l.includes("json") || l.includes("javascript") || l.includes("xml") || l.includes("svg")) {
        const m = await k.text();
        e({
          success: true,
          data: m,
          type: "text"
        });
      } else {
        const n = await k.arrayBuffer();
        const o = new Uint8Array(n);
        let p = "";
        for (let r = 0; r < o.length; r++) {
          p += String.fromCharCode(o[r]);
        }
        const q = btoa(p);
        e({
          success: true,
          data: q,
          type: "binary"
        });
      }
    }).catch(k => {
      e({
        success: false,
        error: k.message
      });
    });
    return true;
  }
});