const bridge = {
  _pending: {},
  _counter: 0,
  _call(c, d) {
    return new Promise((e, f) => {
      const g = "req_" + ++this._counter;
      this._pending[g] = {
        resolve: e,
        reject: f
      };
      window.parent.postMessage({
        requestId: g,
        command: c,
        payload: d
      }, "*");
      const h = c === "lovable.downloadProject" ? 180000 : 15000;
      setTimeout(() => {
        if (this._pending[g]) {
          delete this._pending[g];
          f(new Error("Bridge timeout: " + c));
        }
      }, h);
    });
  },
  _handleResponse(c) {
    const {
      requestId: d,
      ok: e,
      payload: f,
      error: g
    } = c.data || {};
    if (!d || !bridge._pending[d]) {
      return;
    }
    const {
      resolve: h,
      reject: i
    } = bridge._pending[d];
    delete bridge._pending[d];
    if (e) {
      h(f);
    } else {
      i(new Error(g || "Bridge error"));
    }
  },
  storage: {
    get: c => bridge._call("storage.get", {
      keys: c
    }),
    set: c => bridge._call("storage.set", {
      data: c
    })
  },
  auth: {
    getToken: () => bridge._call("auth.getToken")
  },
  project: {
    getActive: () => bridge._call("project.getActive")
  },
  license: {
    getInfo: () => bridge._call("license.getInfo"),
    revalidate: () => bridge._call("license.revalidate"),
    logout: () => bridge._call("license.logout")
  },
  lovable: {
    sendMessage: (c, d, e) => bridge._call("lovable.sendMessage", {
      message: c,
      projectId: d,
      files: e
    }),
    publish: () => bridge._call("lovable.publish"),
    downloadProject: c => bridge._call("lovable.downloadProject", {
      projectId: c
    })
  },
  templates: {
    getAll: () => bridge._call("templates.getAll")
  },
  ai: {
    enhancePrompt: c => bridge._call("ai.enhancePrompt", {
      prompt: c
    })
  },
  runtime: {
    openUrl: c => bridge._call("runtime.openUrl", {
      url: c
    })
  }
};
window.addEventListener("message", c => {
  const {
    command: d,
    payload: f
  } = c.data || {};
  if (d === "chat.captured" && f?.content) {
    addMessage("bot", "💬 " + f.content);
    return;
  }
  if (d === "lovable.suggestions" && Array.isArray(f?.items)) {
    renderQuickSuggestions(f.items);
    return;
  }
  bridge._handleResponse(c);
});
function renderQuickSuggestions(c) {
  const d = document.getElementById("quickSuggestions");
  if (!d) {
    return;
  }
  if (!c.length) {
    d.style.display = "none";
    d.innerHTML = "";
    return;
  }
  const e = new Set();
  const f = [];
  for (const i of c) {
    const j = (i?.text || "").trim();
    if (!j || e.has(j)) {
      continue;
    }
    e.add(j);
    f.push(j);
    if (f.length >= 8) {
      break;
    }
  }
  const g = d.dataset.signature || "";
  const h = f.join("|");
  if (h === g) {
    return;
  }
  d.dataset.signature = h;
  d.innerHTML = "";
  for (const k of f) {
    const l = document.createElement("button");
    l.type = "button";
    l.className = "qs-chip";
    l.textContent = k;
    l.title = k;
    l.addEventListener("click", () => {
      const n = document.getElementById("message");
      if (!n) {
        return;
      }
      n.value = k;
      n.style.height = "auto";
      n.style.height = Math.min(n.scrollHeight, 200) + "px";
      n.focus();
    });
    d.appendChild(l);
  }
  d.style.display = "flex";
}
let history = [];
let pendingFiles = [];
const historyEl = document.getElementById("history");
const messageEl = document.getElementById("message");
const sendBtn = document.getElementById("sendBtn");
const statusEl = document.getElementById("status");
const clearBtn = document.getElementById("clearBtn");
const publishBtn = document.getElementById("publishBtn");
const logoutBtn = document.getElementById("logoutBtn");
const licenseInfoEl = document.getElementById("licenseInfo");
const attachBtn = document.getElementById("attachBtn");
const fileInput = document.getElementById("fileInput");
const filePreview = document.getElementById("filePreview");
function updateStatus(c) {
  if (statusEl) {
    statusEl.textContent = c;
  }
}
function addMessage(c, d) {
  history.push({
    role: c,
    content: d,
    time: new Date().toLocaleTimeString()
  });
  if (history.length > 50) {
    history.shift();
  }
  bridge.storage.set({
    history: history
  });
  renderHistory();
}
function renderHistory() {
  if (!historyEl) {
    return;
  }
  historyEl.innerHTML = "";
  if (history.length === 0) {
    historyEl.innerHTML = "<div class=\"empty-state\"><h3>Pronto para começar</h3><p>Envie uma mensagem para interagir</p></div>";
    return;
  }
  history.forEach(c => {
    const d = document.createElement("div");
    d.className = "message-wrapper " + c.role;
    const e = document.createElement("div");
    e.className = "bubble " + c.role;
    e.textContent = c.content;
    d.appendChild(e);
    historyEl.appendChild(d);
  });
  historyEl.scrollTop = historyEl.scrollHeight;
}
function fileToBase64(c) {
  return new Promise((d, e) => {
    const f = new FileReader();
    f.onload = () => d(f.result);
    f.onerror = e;
    f.readAsDataURL(c);
  });
}
function renderFilePreview() {
  if (!filePreview) {
    return;
  }
  if (pendingFiles.length === 0) {
    filePreview.style.display = "none";
    filePreview.innerHTML = "";
    return;
  }
  filePreview.style.display = "flex";
  filePreview.innerHTML = "";
  pendingFiles.forEach((c, d) => {
    const e = document.createElement("div");
    e.className = "file-chip";
    const g = document.createElement("span");
    g.textContent = c.name.length > 20 ? c.name.slice(0, 17) + "..." : c.name;
    const h = document.createElement("button");
    h.textContent = "×";
    h.onclick = () => {
      pendingFiles.splice(d, 1);
      renderFilePreview();
    };
    e.appendChild(g);
    e.appendChild(h);
    filePreview.appendChild(e);
  });
}
function addFiles(c) {
  const d = 5;
  const e = 52428800;
  for (const f of c) {
    if (pendingFiles.length >= d) {
      break;
    }
    if (f.size > e) {
      addMessage("bot", "❌ Arquivo \"" + f.name + "\" excede 50MB");
      continue;
    }
    pendingFiles.push(f);
  }
  renderFilePreview();
}
attachBtn?.addEventListener("click", () => fileInput?.click());
fileInput?.addEventListener("change", c => {
  if (c.target.files?.length) {
    addFiles(c.target.files);
    fileInput.value = "";
  }
});
messageEl?.addEventListener("dragover", c => {
  c.preventDefault();
  c.stopPropagation();
});
messageEl?.addEventListener("drop", c => {
  c.preventDefault();
  c.stopPropagation();
  if (c.dataTransfer?.files?.length) {
    addFiles(c.dataTransfer.files);
  }
});
messageEl?.addEventListener("paste", c => {
  const d = c.clipboardData?.items;
  if (!d) {
    return;
  }
  const g = [];
  for (const h of d) {
    if (h.kind === "file") {
      const i = h.getAsFile();
      if (i) {
        g.push(i);
      }
    }
  }
  if (g.length) {
    addFiles(g);
  }
});
async function handleSend() {
  const c = messageEl?.value.trim();
  if (!c && pendingFiles.length === 0) {
    return;
  }
  if (!messageEl || !sendBtn) {
    return;
  }
  let d = c || "";
  if (pendingFiles.length > 0) {
    const e = pendingFiles.map(g => g.name).join(", ");
    d += (d ? "\n" : "") + "📎 " + e;
  }
  addMessage("user", d);
  messageEl.value = "";
  sendBtn.disabled = true;
  updateStatus("📤 Enviando...");
  try {
    let f = [];
    if (pendingFiles.length > 0) {
      updateStatus("📤 Processando arquivos...");
      f = await Promise.all(pendingFiles.map(async i => ({
        name: i.name,
        type: i.type,
        size: i.size,
        data: await fileToBase64(i)
      })));
      pendingFiles = [];
      renderFilePreview();
    }
    const {
      projectId: g
    } = await bridge.project.getActive();
    let h;
    if (f.length > 0) {
      h = await bridge.lovable.sendMessage(c || "", g, f);
    } else {
      h = await bridge.lovable.sendMessage(c, g);
    }
    if (h?.reply) {
      addMessage("bot", h.reply);
    } else if (h?.output) {
      addMessage("bot", h.output);
    } else if (h?.message) {
      addMessage("bot", h.message);
    } else {
      addMessage("bot", "✅ Comando processado!");
    }
    updateStatus("✅ Pronto");
  } catch (i) {
    addMessage("bot", "❌ " + (i?.message || "Erro ao enviar"));
    updateStatus("❌ Erro");
  } finally {
    sendBtn.disabled = false;
  }
}
sendBtn?.addEventListener("click", handleSend);
messageEl?.addEventListener("keydown", c => {
  if (c.key === "Enter" && !c.shiftKey) {
    c.preventDefault();
    handleSend();
  }
});
messageEl?.addEventListener("input", () => {
  if (!messageEl) {
    return;
  }
  messageEl.style.height = "auto";
  messageEl.style.height = Math.min(messageEl.scrollHeight, 200) + "px";
});
const removeWatermarkBtn = document.getElementById("removeWatermarkBtn");
removeWatermarkBtn?.addEventListener("click", () => {
  if (!messageEl) {
    return;
  }
  messageEl.value = "Adicione esse código no final do código do index.css:\n\n#lovable-badge {\n  display: none !important;\n}";
  handleSend();
});
clearBtn?.addEventListener("click", () => {
  history = [];
  bridge.storage.set({
    history: []
  });
  renderHistory();
});
logoutBtn?.addEventListener("click", () => bridge.license.logout());
const enhanceBtn = document.getElementById("enhanceBtn");
enhanceBtn?.addEventListener("click", async () => {
  if (!messageEl) {
    return;
  }
  const c = messageEl.value.trim();
  if (!c) {
    updateStatus("⚠️ Digite algo para melhorar");
    return;
  }
  enhanceBtn.disabled = true;
  enhanceBtn.classList.add("loading");
  const d = enhanceBtn.querySelector("span");
  const e = d?.textContent;
  if (d) {
    d.textContent = "Otimizando...";
  }
  updateStatus("✨ Melhorando prompt...");
  try {
    const f = await bridge.ai.enhancePrompt(c);
    if (f?.improved) {
      messageEl.value = f.improved;
      messageEl.style.height = "auto";
      messageEl.style.height = Math.min(messageEl.scrollHeight, 200) + "px";
      messageEl.focus();
      updateStatus("✅ Prompt otimizado");
    } else {
      throw new Error(f?.error || "Resposta vazia");
    }
  } catch (g) {
    addMessage("bot", "❌ " + (g?.message || "Erro ao melhorar prompt"));
    updateStatus("❌ Erro");
  } finally {
    enhanceBtn.disabled = false;
    enhanceBtn.classList.remove("loading");
    if (d && e) {
      d.textContent = e;
    }
  }
});
const downloadBtn = document.getElementById("downloadBtn");
downloadBtn?.addEventListener("click", async () => {
  downloadBtn.disabled = true;
  downloadBtn.style.opacity = "0.5";
  updateStatus("⬇️ Preparando download...");
  try {
    const {
      projectId: c
    } = await bridge.project.getActive();
    if (!c) {
      throw new Error("Nenhum projeto ativo");
    }
    const d = await bridge.lovable.downloadProject(c);
    if (d?.success) {
      addMessage("bot", "✅ Download iniciado!");
      updateStatus("✅ Download iniciado");
    } else {
      throw new Error(d?.error || "Erro ao baixar");
    }
  } catch (e) {
    addMessage("bot", "❌ " + (e?.message || "Erro ao baixar projeto"));
    updateStatus("❌ Erro no download");
  } finally {
    downloadBtn.disabled = false;
    downloadBtn.style.opacity = "1";
  }
});
publishBtn?.addEventListener("click", async () => {
  publishBtn.disabled = true;
  try {
    const c = await bridge.lovable.publish();
    if (c?.success) {
      addMessage("bot", "✅ Projeto publicado! 🚀");
    } else {
      addMessage("bot", "❌ " + (c?.error || "Erro ao publicar"));
    }
  } catch (d) {
    addMessage("bot", "❌ " + (d?.message || "Erro ao publicar"));
  } finally {
    publishBtn.disabled = false;
  }
});
const tabChat = document.getElementById("tabChat");
const tabTemplates = document.getElementById("tabTemplates");
const chatPanel = document.getElementById("chatPanel");
const templatesPanel = document.getElementById("templatesPanel");
const templatesLoading = document.getElementById("templatesLoading");
let templatesLoaded = false;
let cachedTemplates = [];
function switchTab(c) {
  if (c === "chat") {
    tabChat?.classList.add("active");
    tabTemplates?.classList.remove("active");
    if (chatPanel) {
      chatPanel.classList.remove("hidden");
    }
    if (templatesPanel) {
      templatesPanel.classList.remove("visible");
    }
  } else {
    tabTemplates?.classList.add("active");
    tabChat?.classList.remove("active");
    if (chatPanel) {
      chatPanel.classList.add("hidden");
    }
    if (templatesPanel) {
      templatesPanel.classList.add("visible");
    }
    if (!templatesLoaded) {
      loadTemplates();
    }
  }
}
tabChat?.addEventListener("click", () => switchTab("chat"));
tabTemplates?.addEventListener("click", () => switchTab("templates"));
async function loadTemplates() {
  if (templatesLoading) {
    templatesLoading.style.display = "flex";
  }
  try {
    const c = await bridge.templates.getAll();
    cachedTemplates = c?.templates || [];
    templatesLoaded = true;
    renderTemplates();
  } catch (d) {
    console.error("Error loading templates:", d);
    if (templatesPanel) {
      templatesPanel.innerHTML = "<div class=\"templates-empty\"><p>❌ Erro ao carregar templates</p></div>";
    }
  }
}
function renderTemplates() {
  if (!templatesPanel) {
    return;
  }
  templatesPanel.innerHTML = "";
  if (cachedTemplates.length === 0) {
    templatesPanel.innerHTML = "<div class=\"templates-empty\"><p>Nenhum template disponível</p></div>";
    return;
  }
  const c = {};
  cachedTemplates.forEach(d => {
    const e = d.category || "Geral";
    if (!c[e]) {
      c[e] = [];
    }
    c[e].push(d);
  });
  Object.keys(c).sort().forEach(d => {
    const e = document.createElement("div");
    e.className = "template-category";
    e.textContent = d;
    templatesPanel.appendChild(e);
    c[d].forEach(f => {
      const g = document.createElement("div");
      g.className = "template-card";
      const h = document.createElement("div");
      h.className = "template-thumb";
      if (f.video_url) {
        const m = document.createElement("video");
        m.src = f.video_url;
        m.autoplay = true;
        m.loop = true;
        m.muted = true;
        m.playsInline = true;
        h.appendChild(m);
      } else if (f.image_url) {
        const n = document.createElement("img");
        n.src = f.image_url;
        n.alt = f.name;
        n.loading = "lazy";
        h.appendChild(n);
      } else {
        h.textContent = "📄";
      }
      g.appendChild(h);
      const i = document.createElement("div");
      i.className = "template-bottom";
      const j = document.createElement("div");
      j.className = "template-info";
      const k = document.createElement("div");
      k.className = "template-name";
      k.textContent = f.name;
      j.appendChild(k);
      if (f.description) {
        const o = document.createElement("div");
        o.className = "template-desc";
        o.textContent = f.description;
        j.appendChild(o);
      }
      const l = document.createElement("button");
      l.className = "template-use";
      l.textContent = "Usar";
      l.addEventListener("click", p => {
        p.stopPropagation();
        useTemplate(f);
      });
      i.appendChild(j);
      i.appendChild(l);
      g.appendChild(i);
      g.addEventListener("click", () => useTemplate(f));
      templatesPanel.appendChild(g);
    });
  });
}
function useTemplate(c) {
  switchTab("chat");
  if (messageEl) {
    messageEl.value = c.code;
    messageEl.focus();
    messageEl.style.height = "auto";
    messageEl.style.height = Math.min(messageEl.scrollHeight, 120) + "px";
  }
}
(async () => {
  try {
    const c = await bridge.storage.get(["history"]);
    if (c?.history) {
      history = c.history;
      renderHistory();
    }
    const d = await bridge.license.getInfo();
    if (d?.licenseInfo && licenseInfoEl) {
      const f = d.licenseInfo;
      if (f.hours_remaining && f.hours_remaining < 24) {
        licenseInfoEl.textContent = f.hours_remaining + "h";
      } else if (f.days_remaining) {
        licenseInfoEl.textContent = f.days_remaining + " dias";
      } else {
        licenseInfoEl.textContent = "Ativo";
      }
    }
    const {
      projectId: e
    } = await bridge.project.getActive();
    if (e) {
      updateStatus("✅ Projeto: " + e.slice(0, 8) + "...");
    } else {
      updateStatus("⚠️ Abra um projeto no Lovable.dev");
    }
  } catch (g) {
    updateStatus("⚠️ Inicializando...");
    console.warn("Init error:", g);
  }
})();