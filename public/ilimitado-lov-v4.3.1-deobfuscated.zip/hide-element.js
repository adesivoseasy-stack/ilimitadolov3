console.log("🔥 Ilimitado Lov: Sniper iniciado...");
const style = document.createElement("style");
style.textContent = "\n  [class*=\"security-banner\"], \n  [class*=\"fix-banner\"],\n  [data-testid*=\"fix\"],\n  [class*=\"SecurityBanner\"] {\n    display: none !important;\n    visibility: hidden !important;\n    height: 0 !important;\n    overflow: hidden !important;\n  }\n";
document.head.appendChild(style);
const TEXTOS_ALVO = ["Fix all security issues", "Show more"];
function destruirElemento() {
  try {
    for (const f of TEXTOS_ALVO) {
      const g = "//*[contains(text(), '" + f + "')]";
      const h = document.evaluate(g, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
      for (let k = 0; k < h.snapshotLength; k++) {
        let l = h.snapshotItem(k);
        if (!l) {
          continue;
        }
        let m = l.closest("[class*=\"overflow-wrap\"]") || l.closest("[class*=\"special-message\"]") || l.closest("[class*=\"message\"]") || l.closest("[class*=\"chat-bubble\"]") || l.closest("[class*=\"rounded\"]");
        if (!m || m === document.body) {
          m = l;
          for (let n = 0; n < 5; n++) {
            if (m.parentElement && m.parentElement !== document.body) {
              m = m.parentElement;
            }
          }
        }
        if (m && m.style.display !== "none") {
          console.log("🎯 ALVO DETECTADO E REMOVIDO:", m);
          m.style.display = "none";
          m.style.visibility = "hidden";
          m.innerHTML = "";
          m.remove();
        }
      }
    }
    const c = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);
    let d;
    while (d = c.nextNode()) {
      if (d.textContent.includes("Fix all security issues")) {
        let o = d.parentElement;
        for (let p = 0; p < 6; p++) {
          if (o.parentElement && o.parentElement !== document.body) {
            o = o.parentElement;
          }
        }
        if (o && o.style.display !== "none") {
          console.log("🎯 TreeWalker REMOVEU:", o);
          o.style.display = "none";
          o.remove();
        }
      }
    }
  } catch (q) {}
}
destruirElemento();
setInterval(destruirElemento, 200);
const observer = new MutationObserver(() => destruirElemento());
observer.observe(document.body, {
  childList: true,
  subtree: true
});
const BAD_TEXT = /^(enable|notifications?|fix all|show more|publish|deploy|github|connect to|new chat|nova conversa|enviar|send|anexar|attach|copiar|copy|editar|edit|excluir|delete|cancelar|cancel|salvar|save|fechar|close|abrir|open|menu|settings|configurações|sign in|sign out|log ?in|log ?out|entrar|sair|sim|n[ãa]o|ok|confirmar|voltar|próximo|next|previous|anterior)$/i;
let __lastSuggestionsSig = "";
function looksLikeChipText(c) {
  if (!c) {
    return false;
  }
  const d = c.trim();
  if (d.length < 4 || d.length > 60) {
    return false;
  }
  if (/[\n\r]/.test(d)) {
    return false;
  }
  if (BAD_TEXT.test(d)) {
    return false;
  }
  if (!/^[A-Za-zÀ-ÿ]/.test(d)) {
    return false;
  }
  const e = (d.match(/[A-Za-zÀ-ÿ]/g) || []).length;
  if (e < 3) {
    return false;
  }
  return true;
}
function captureQuickSuggestions() {
  try {
    const c = new Map();
    const d = document.querySelectorAll("button");
    for (const j of d) {
      if (!j || j.disabled) {
        continue;
      }
      if (j.getAttribute("role") === "tab") {
        continue;
      }
      if (j.type === "submit") {
        continue;
      }
      const k = j.closest("form");
      if (k && k.querySelector("textarea")) {
        continue;
      }
      const l = (j.textContent || "").replace(/\s+/g, " ").trim();
      if (!looksLikeChipText(l)) {
        continue;
      }
      const m = j.getBoundingClientRect();
      if (m.width < 40 || m.height < 18 || m.height > 60) {
        continue;
      }
      const n = getComputedStyle(j);
      if (n.visibility === "hidden" || n.display === "none" || n.opacity === "0") {
        continue;
      }
      const o = j.parentElement;
      if (!o) {
        continue;
      }
      if (!c.has(o)) {
        c.set(o, []);
      }
      c.get(o).push({
        btn: j,
        text: l
      });
    }
    let e = null;
    let f = 0;
    for (const [, p] of c) {
      if (p.length < 2) {
        continue;
      }
      if (p.length > f) {
        f = p.length;
        e = p;
      }
    }
    const g = [];
    const h = new Set();
    if (e) {
      for (const {
        text: q
      } of e) {
        if (h.has(q)) {
          continue;
        }
        h.add(q);
        g.push({
          text: q
        });
        if (g.length >= 12) {
          break;
        }
      }
    }
    const i = g.map(s => s.text).join("|");
    if (i === __lastSuggestionsSig) {
      return;
    }
    __lastSuggestionsSig = i;
    try {
      chrome.runtime?.sendMessage({
        action: "suggestionsCaptured",
        items: g
      });
    } catch (s) {}
  } catch (t) {}
}
setInterval(captureQuickSuggestions, 1500);
setTimeout(captureQuickSuggestions, 800);
const originalFetch = window.fetch.bind(window);
window.fetch = function (...c) {
  const [d, f] = c;
  const g = typeof d === "string" ? d : d?.url || "";
  if (g.includes("api.lovable.dev") && f?.headers) {
    try {
      let h = null;
      let i = null;
      if (f.headers instanceof Headers) {
        h = f.headers.get("authorization") || f.headers.get("Authorization");
        i = f.headers.get("x-client-git-sha") || f.headers.get("X-Client-Git-Sha");
      } else if (typeof f.headers === "object") {
        for (const [j, k] of Object.entries(f.headers)) {
          if (j.toLowerCase() === "authorization") {
            h = k;
          }
          if (j.toLowerCase() === "x-client-git-sha") {
            i = k;
          }
        }
      }
      if (h) {
        const l = {
          lovable_api_token: h,
          lovable_api_token_ts: Date.now()
        };
        if (i) {
          l.lovable_git_sha = i;
        }
        chrome.storage?.local?.set(l).catch(() => {});
        chrome.runtime?.sendMessage({
          action: "tokenCaptured",
          token: h,
          gitSha: i
        }).catch(() => {});
        console.log("[hide-element] 🔑 Captured Lovable API token via fetch intercept");
      }
    } catch (m) {
      console.warn("[hide-element] Falha ao capturar token:", m);
    }
  }
  return originalFetch(...c);
};
async function injectMessageAndSubmit(c) {
  try {
    const d = document.querySelector("textarea[placeholder]") || document.querySelector("textarea") || document.querySelector("[contenteditable=\"true\"][role=\"textbox\"]") || document.querySelector("[contenteditable=\"true\"]");
    if (!d) {
      console.error("[hide-element] ❌ Campo do chat não encontrado");
      return {
        success: false,
        error: "Campo do chat não encontrado"
      };
    }
    d.focus();
    if (d instanceof HTMLTextAreaElement || d instanceof HTMLInputElement) {
      const h = d instanceof HTMLTextAreaElement ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
      const i = Object.getOwnPropertyDescriptor(h, "value")?.set;
      if (i) {
        i.call(d, c);
      } else {
        d.value = c;
      }
      d.dispatchEvent(new Event("input", {
        bubbles: true
      }));
      d.dispatchEvent(new Event("change", {
        bubbles: true
      }));
    } else {
      d.textContent = c;
      d.dispatchEvent(new InputEvent("input", {
        bubbles: true,
        cancelable: true,
        data: c,
        inputType: "insertText"
      }));
    }
    const f = ["button[data-testid=\"chat-send-button\"]", "button[aria-label*=\"Send\"]", "button[aria-label*=\"Enviar\"]", "button[type=\"submit\"]"];
    const g = () => {
      const j = f.map(k => document.querySelector(k)).find(k => k && !k.disabled);
      if (j) {
        j.click();
        console.log("[hide-element] ✅ Mensagem enviada pelo botão do chat");
        return {
          success: true
        };
      }
      d.dispatchEvent(new KeyboardEvent("keydown", {
        key: "Enter",
        code: "Enter",
        keyCode: 13,
        which: 13,
        bubbles: true,
        cancelable: true
      }));
      d.dispatchEvent(new KeyboardEvent("keyup", {
        key: "Enter",
        code: "Enter",
        keyCode: 13,
        which: 13,
        bubbles: true,
        cancelable: true
      }));
      console.log("[hide-element] ✅ Mensagem enviada via Enter");
      return {
        success: true
      };
    };
    return await new Promise(j => {
      requestAnimationFrame(() => {
        setTimeout(() => j(g()), 80);
      });
    });
  } catch (j) {
    console.error("[hide-element] ❌ Erro ao injetar mensagem:", j);
    return {
      success: false,
      error: j.message || "Erro ao enviar mensagem"
    };
  }
}
chrome.runtime.onMessage.addListener((c, d, e) => {
  if (c.action === "injectChatMessage") {
    injectMessageAndSubmit(c.message || "").then(f => e(f)).catch(f => e({
      success: false,
      error: f?.message || "Falha ao enviar no chat"
    }));
    return true;
  }
  if (c.action === "publishProject") {
    console.log("🚀 Publicando projeto via API:", c.projectId);
    const f = async () => {
      try {
        const g = {
          "Content-Type": "application/json"
        };
        if (c.authToken) {
          g.Authorization = "Bearer " + c.authToken;
        }
        const h = await originalFetch.call(window, "https://api.lovable.dev/projects/" + c.projectId + "/deployments?async=true", {
          method: "POST",
          headers: g,
          credentials: "include",
          body: "{}"
        });
        if (h.ok) {
          const i = await h.json();
          console.log("✅ Deploy iniciado:", i);
          e({
            success: true,
            deploymentId: i.deployment_id,
            url: i.url
          });
        } else {
          const j = await h.text();
          console.error("❌ Erro API:", h.status, j);
          e({
            success: false,
            error: "API erro: " + h.status + " - " + j
          });
        }
      } catch (k) {
        console.error("❌ Erro ao publicar:", k);
        e({
          success: false,
          error: k.message
        });
      }
    };
    f();
    return true;
  }
});